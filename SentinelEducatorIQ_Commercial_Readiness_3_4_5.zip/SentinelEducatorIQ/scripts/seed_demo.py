"""Create a deterministic, fictional executive demonstration environment.

Usage:
    python scripts/seed_demo.py --reset

All names and records are synthetic and must not be treated as real student data.
"""
from __future__ import annotations

import argparse
import json
import os
import random
import sqlite3
import sys
from datetime import date, timedelta
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

from database import (  # noqa: E402
    DATABASE_PATH,
    connection,
    generate_password_hash,
    initialize_accreditation,
    initialize_database,
    initialize_executive_experience,
    initialize_step4,
    initialize_step5,
    initialize_step6,
    initialize_step7,
    initialize_step8,
    initialize_step9,
    save_executive_snapshot,
)
from services.executive_analytics import build_period_snapshot  # noqa: E402

RNG = random.Random(20260728)

PROGRAMS = [
    ("Accounting", "Bachelor", 120, "College of Business"),
    ("Business Administration", "Bachelor", 120, "College of Business"),
    ("Finance", "Bachelor", 120, "College of Business"),
    ("Health Services Administration", "Bachelor", 120, "College of Health Sciences"),
    ("Biomedical Sciences", "Bachelor", 120, "College of Health Sciences"),
    ("Nursing", "Bachelor", 120, "College of Health Sciences"),
    ("Radiologic Technology", "Associate", 60, "College of Health Sciences"),
    ("Diagnostic Medical Sonography", "Associate", 60, "College of Health Sciences"),
    ("Information Technology", "Bachelor", 120, "College of Technology"),
    ("Cybersecurity", "Bachelor", 120, "College of Technology"),
    ("Digital Forensics", "Bachelor", 120, "College of Technology"),
    ("Software Engineering", "Bachelor", 120, "College of Technology"),
    ("Criminal Justice", "Bachelor", 120, "College of Public Service"),
    ("Homeland Security", "Bachelor", 120, "College of Public Service"),
    ("Legal Studies", "Associate", 60, "College of Public Service"),
    ("Exercise and Sport Science", "Bachelor", 120, "College of Arts and Sciences"),
    ("Psychology", "Bachelor", 120, "College of Arts and Sciences"),
    ("General Studies", "Associate", 60, "College of Arts and Sciences"),
]

FIRST_NAMES = [
    "Avery", "Jordan", "Taylor", "Morgan", "Cameron", "Riley", "Parker", "Quinn",
    "Sydney", "Reese", "Emerson", "Hayden", "Rowan", "Dakota", "Kendall", "Alexis",
    "Maya", "Noah", "Elijah", "Sophia", "Olivia", "Amara", "Mateo", "Liam",
]
LAST_NAMES = [
    "Carter", "Brooks", "Rivera", "Morgan", "Patel", "Johnson", "Lee", "Williams",
    "Thomas", "Martin", "Garcia", "Harris", "Robinson", "Clark", "Lewis", "Walker",
    "Young", "Allen", "King", "Wright", "Scott", "Green", "Baker", "Adams",
]

PERIODS = [
    ("Fall 2025", "2025-08-25", "2025-12-19"),
    ("Spring 2026", "2026-01-12", "2026-05-08"),
    ("Summer 2026", "2026-05-18", "2026-08-07"),
    ("Fall 2026", "2026-08-24", "2026-12-18"),
]

ROLE_USERS = [
    ("president@demo.edu", "Dr. Avery Williams", "president"),
    ("provost@demo.edu", "Dr. Morgan Ellis", "provost"),
    ("dean.business@demo.edu", "Dr. Jordan Brooks", "dean"),
    ("director.it@demo.edu", "Taylor Reed", "program_director"),
    ("advisor@demo.edu", "Cameron Price", "advisor"),
]

DEMO_PASSWORD = "Demo-Executive-2026!"


def reset_database() -> None:
    path = Path(DATABASE_PATH)
    if path.exists():
        path.unlink()


def build_schema() -> int:
    institution_id = initialize_database()
    initialize_step4(institution_id)
    initialize_step5(institution_id)
    initialize_step6(institution_id)
    initialize_step7(institution_id)
    initialize_step8(institution_id)
    initialize_step9(institution_id)
    initialize_accreditation(institution_id)
    initialize_executive_experience(institution_id)
    return institution_id


def create_hierarchy(conn: sqlite3.Connection, institution_id: int):
    conn.execute(
        "UPDATE institutions SET name=?, code=? WHERE id=?",
        ("Hamilton Metropolitan University", "HMU-DEMO", institution_id),
    )
    conn.execute("DELETE FROM student_organization_assignments")
    conn.execute("DELETE FROM user_scopes")
    conn.execute("DELETE FROM organization_units WHERE institution_id=?", (institution_id,))
    root = conn.execute(
        "INSERT INTO organization_units (institution_id, unit_type, name, code) VALUES (?, 'Institution', ?, ?)",
        (institution_id, "Hamilton Metropolitan University", "HMU-DEMO"),
    ).lastrowid
    campus = conn.execute(
        "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'Campus', ?, ?)",
        (institution_id, root, "Metropolitan Campus", "METRO"),
    ).lastrowid
    colleges = {}
    for college_name in sorted({p[3] for p in PROGRAMS}):
        code = "COL-" + "".join(c for c in college_name.upper() if c.isalnum())[:18]
        colleges[college_name] = conn.execute(
            "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'College', ?, ?)",
            (institution_id, campus, college_name, code),
        ).lastrowid
    program_units = {}
    for program, _, _, college in PROGRAMS:
        code = "PRG-" + "".join(c for c in program.upper() if c.isalnum())[:22]
        program_units[program] = conn.execute(
            "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'Program', ?, ?)",
            (institution_id, colleges[college], program, code),
        ).lastrowid
    return root, colleges, program_units


def create_periods(conn: sqlite3.Connection, institution_id: int):
    conn.execute("DELETE FROM executive_kpi_snapshots WHERE institution_id=?", (institution_id,))
    conn.execute("DELETE FROM reporting_periods WHERE institution_id=?", (institution_id,))
    ids = []
    for index, (name, start, end) in enumerate(PERIODS):
        ids.append(conn.execute(
            """INSERT INTO reporting_periods
               (institution_id, name, period_type, start_date, end_date, status, is_current)
               VALUES (?, ?, 'Term', ?, ?, 'Open', ?)""",
            (institution_id, name, start, end, 1 if index == len(PERIODS) - 1 else 0),
        ).lastrowid)
    return ids


def synthetic_metric(program: str, period_index: int, student_index: int):
    base = 81 + period_index * 1.2
    if program in {"Nursing", "Software Engineering", "Biomedical Sciences"}:
        base -= 4.5
    if program in {"Accounting", "Cybersecurity", "Radiologic Technology"}:
        base += 2.5
    personal = RNG.gauss(0, 10)
    grade = max(35, min(99, base + personal))
    gpa = max(1.0, min(4.0, 1.2 + grade / 35 + RNG.gauss(0, .18)))
    if grade < 60:
        risk, missing = "High", RNG.randint(5, 9)
    elif grade < 75:
        risk, missing = "Moderate", RNG.randint(2, 5)
    else:
        risk, missing = "Low", RNG.randint(0, 2)
    return round(grade, 1), round(gpa, 2), risk, missing


def seed_students(conn: sqlite3.Connection, institution_id: int, period_ids, program_units, count: int):
    conn.execute("DELETE FROM student_period_records")
    conn.execute("DELETE FROM students WHERE institution_id=?", (institution_id,))
    for i in range(1, count + 1):
        program, degree, required, _ = PROGRAMS[(i - 1) % len(PROGRAMS)]
        name = f"{FIRST_NAMES[(i * 7) % len(FIRST_NAMES)]} {LAST_NAMES[(i * 11) % len(LAST_NAMES)]}"
        external_id = f"HMU{i:06d}"
        student_id = conn.execute(
            "INSERT INTO students (institution_id, external_student_id, name, program, degree_level) VALUES (?, ?, ?, ?, ?)",
            (institution_id, external_id, name, program, degree),
        ).lastrowid
        conn.execute(
            "INSERT INTO student_organization_assignments (student_id, organization_unit_id) VALUES (?, ?)",
            (student_id, program_units[program]),
        )
        starting_credits = RNG.randint(6, max(12, required - 36))
        for p_index, period_id in enumerate(period_ids):
            grade, gpa, risk, missing = synthetic_metric(program, p_index, i)
            completed = min(required, starting_credits + p_index * RNG.randint(9, 15))
            minutes = max(30, round(RNG.gauss(410 if risk == "Low" else 260 if risk == "Moderate" else 130, 75), 1))
            course_code = f"{''.join(w[0] for w in program.split())[:3].upper()}{100 + (i % 40)}"
            missing_courses = [] if completed >= required else [
                {"name": f"{course_code} Capstone Requirement", "credits": 3}
            ]
            recommendation = (
                "Immediate advisor outreach and academic support plan." if risk == "High" else
                "Monitor progress and reinforce tutoring resources." if risk == "Moderate" else
                "Continue current academic plan."
            )
            conn.execute(
                """INSERT INTO student_period_records
                   (student_id, reporting_period_id, gpa, attendance_risk, completed_credits,
                    required_credits, course_code, course_name, instructor, learn_grade,
                    blackboard_minutes, missing_assignments_count, missing_courses_json,
                    recommendation, source_filename)
                   VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                (student_id, period_id, gpa, risk, completed, required, course_code,
                 f"{program} Core Course", f"Professor {LAST_NAMES[(i + p_index) % len(LAST_NAMES)]}",
                 grade, minutes, missing, json.dumps(missing_courses), recommendation,
                 "synthetic_demo_data.csv"),
            )


def seed_users(conn: sqlite3.Connection, institution_id: int, root: int, colleges, program_units):
    conn.execute("DELETE FROM users WHERE institution_id=?", (institution_id,))
    users = [("admin@demo.edu", "Sentinel Demo Administrator", "super_admin")] + ROLE_USERS
    for email, name, role in users:
        user_id = conn.execute(
            """INSERT INTO users
               (institution_id, email, full_name, password_hash, role, is_active, must_change_password)
               VALUES (?, ?, ?, ?, ?, 1, 0)""",
            (institution_id, email, name, generate_password_hash(DEMO_PASSWORD), role),
        ).lastrowid
        scope = root
        if role == "dean":
            scope = colleges["College of Business"]
        elif role == "program_director":
            scope = program_units["Information Technology"]
        conn.execute("INSERT INTO user_scopes (user_id, organization_unit_id) VALUES (?, ?)", (user_id, scope))


def seed_branding_and_compliance(conn: sqlite3.Connection, institution_id: int):
    conn.execute(
        """INSERT INTO institution_branding
           (institution_id, display_name, logo_url, primary_color, secondary_color, accent_color,
            platform_subtitle, powered_by_text)
           VALUES (?, ?, '', '#0b172a', '#1d4ed8', '#d4a72c', ?, ?)
           ON CONFLICT(institution_id) DO UPDATE SET display_name=excluded.display_name,
             primary_color=excluded.primary_color, secondary_color=excluded.secondary_color,
             accent_color=excluded.accent_color, platform_subtitle=excluded.platform_subtitle,
             powered_by_text=excluded.powered_by_text""",
        (institution_id, "Hamilton Metropolitan University",
         "Executive Academic Intelligence Platform", "Powered by SentinelEducatorIQ™"),
    )
    conn.execute("DELETE FROM accreditation_items WHERE institution_id=?", (institution_id,))
    today = date.today()
    items = [
        ("SACSCOC", "8.2.a", "Student outcomes: educational programs", "Institutional Accreditation", "Office of Institutional Effectiveness", 44, "At Risk", 66, 24, 14, "High", "Six programs need complete closing-the-loop evidence."),
        ("SACSCOC", "6.2.a", "Faculty qualifications", "Academic Compliance", "Office of Academic Affairs", 73, "In Progress", 78, 40, 31, "Moderate", "Update graduate transcript and credential files."),
        ("Federal", "Title IV", "Administrative capability", "Federal Compliance", "Financial Aid", 160, "On Track", 94, 18, 18, "Low", "Quarterly review completed."),
        ("State", "Licensure", "Professional licensure disclosures", "State Compliance", "Compliance Office", 31, "At Risk", 70, 12, 8, "High", "Update disclosures for four distance-education states."),
        ("ACEN", "Standard 4", "Curriculum and student outcomes", "Programmatic Accreditation", "Dean of Health Sciences", 95, "In Progress", 83, 22, 18, "Moderate", "Nursing outcome evidence is being reconciled."),
        ("Institutional", "Annual Assessment", "Program assessment cycle completion", "Academic Compliance", "Assessment Office", 60, "In Progress", 81, 54, 43, "Moderate", "Nine programs remain in review."),
    ]
    for accreditor, code, title, category, owner, days, status, readiness, req, complete, risk, notes in items:
        conn.execute(
            """INSERT INTO accreditation_items
               (institution_id, accreditor, standard_code, standard_title, category, owner, due_date,
                status, readiness_score, evidence_required, evidence_complete, risk_level, notes)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (institution_id, accreditor, code, title, category, owner,
             (today + timedelta(days=days)).isoformat(), status, readiness, req, complete, risk, notes),
        )


def seed_snapshots(institution_id: int, period_ids):
    with connection() as conn:
      for period_id in period_ids:
        rows = conn.execute(
            """SELECT s.external_student_id AS id, s.name, s.program, s.degree_level,
                      r.gpa, r.attendance_risk, r.completed_credits AS completed,
                      r.required_credits AS required, r.course_code, r.course_name,
                      r.instructor, r.learn_grade, r.blackboard_minutes,
                      r.missing_assignments_count, r.missing_courses_json, r.recommendation
               FROM student_period_records r JOIN students s ON s.id=r.student_id
               WHERE s.institution_id=? AND r.reporting_period_id=?""",
            (institution_id, period_id),
        ).fetchall()
        snapshot = build_period_snapshot([dict(row) for row in rows])
        save_executive_snapshot(institution_id, period_id, snapshot)


def seed_demo(count: int, reset: bool) -> None:
    if reset:
        reset_database()
    institution_id = build_schema()
    with connection() as conn:
        root, colleges, program_units = create_hierarchy(conn, institution_id)
        period_ids = create_periods(conn, institution_id)
        seed_students(conn, institution_id, period_ids, program_units, count)
        seed_users(conn, institution_id, root, colleges, program_units)
        seed_branding_and_compliance(conn, institution_id)
    seed_snapshots(institution_id, period_ids)
    print(f"Created Hamilton Metropolitan University demo with {count:,} students across {len(period_ids)} reporting periods.")
    print("Demo login: admin@demo.edu / " + DEMO_PASSWORD)
    print("Additional role accounts use the same password and are listed in docs/DEMO_GUIDE.md.")


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("--students", type=int, default=1200, help="Number of synthetic students")
    parser.add_argument("--reset", action="store_true", help="Delete and rebuild the local database")
    args = parser.parse_args()
    seed_demo(max(100, args.students), args.reset)
