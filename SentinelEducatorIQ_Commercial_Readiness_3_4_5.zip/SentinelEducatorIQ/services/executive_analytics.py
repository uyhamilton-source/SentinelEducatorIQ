from collections import Counter, defaultdict


def safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def risk_level(student):
    grade = safe_float(student.get("learn_grade"), 100)
    attendance = str(student.get("attendance_risk") or "Low").title()
    missing = int(safe_float(student.get("missing_assignments_count"), 0))
    if grade < 60 or attendance == "High" or missing >= 5:
        return "High"
    if grade < 75 or attendance == "Moderate" or missing >= 2:
        return "Moderate"
    return "Low"


def build_period_snapshot(records):
    total = len(records)
    grades = [safe_float(r.get("learn_grade")) for r in records if str(r.get("learn_grade", "")).strip()]
    gpas = [safe_float(r.get("gpa")) for r in records if str(r.get("gpa", "")).strip()]
    progresses = []
    for r in records:
        required = max(1, int(safe_float(r.get("required"), 1)))
        completed = int(safe_float(r.get("completed"), 0))
        progresses.append(min(100, completed / required * 100))
    risks = Counter(risk_level(r) for r in records)
    missing = sum(int(safe_float(r.get("missing_assignments_count"), 0)) for r in records)
    avg_grade = round(sum(grades) / len(grades), 1) if grades else 0
    avg_gpa = round(sum(gpas) / len(gpas), 2) if gpas else 0
    avg_progress = round(sum(progresses) / len(progresses), 1) if progresses else 0
    success_rate = round(sum(1 for g in grades if g >= 70) / len(grades) * 100, 1) if grades else 0
    academic = max(0, min(100, avg_grade))
    progress = max(0, min(100, avg_progress))
    risk = 100 if total == 0 else max(0, 100 - ((risks["High"] * 20 + risks["Moderate"] * 8) / total))
    engagement = 100 if total == 0 else max(0, 100 - min(100, (missing / total) * 10))
    health = round(academic * .35 + progress * .25 + risk * .25 + engagement * .15)
    return {
        "total_students": total,
        "average_grade": avg_grade,
        "average_gpa": avg_gpa,
        "average_progress": avg_progress,
        "success_rate": success_rate,
        "high_risk": risks["High"],
        "moderate_risk": risks["Moderate"],
        "low_risk": risks["Low"],
        "missing_assignments": missing,
        "institution_health": health,
        "academic_score": round(academic),
        "progress_score": round(progress),
        "risk_score": round(risk),
        "engagement_score": round(engagement),
    }


def percent_change(current, previous):
    if previous in (None, 0):
        return None
    return round((current - previous) / abs(previous) * 100, 1)


def compare_snapshots(current, previous):
    definitions = [
        ("Students Monitored", "total_students", False, "count"),
        ("Course Success", "success_rate", True, "percent"),
        ("Average GPA", "average_gpa", True, "decimal"),
        ("Degree Progress", "average_progress", True, "percent"),
        ("High-Risk Students", "high_risk", False, "count"),
        ("Missing Assignments", "missing_assignments", False, "count"),
        ("Institution Health", "institution_health", True, "score"),
    ]
    rows = []
    for label, key, higher_is_better, fmt in definitions:
        current_value = current.get(key, 0)
        previous_value = previous.get(key) if previous else None
        delta = None if previous_value is None else round(current_value - previous_value, 2)
        pct = percent_change(current_value, previous_value)
        if delta is None or delta == 0:
            direction = "Stable" if delta == 0 else "New"
            status = "neutral"
        else:
            direction = "Improving" if (delta > 0) == higher_is_better else "Needs Attention"
            status = "positive" if direction == "Improving" else "negative"
        rows.append({"label": label, "key": key, "current": current_value, "previous": previous_value,
                     "delta": delta, "percent_change": pct, "direction": direction, "status": status, "format": fmt})
    return rows


def build_program_scorecards(records, previous_records=None):
    previous_records = previous_records or []
    current_groups, previous_groups = defaultdict(list), defaultdict(list)
    for r in records:
        current_groups[str(r.get("program") or "Unassigned")].append(r)
    for r in previous_records:
        previous_groups[str(r.get("program") or "Unassigned")].append(r)
    rows = []
    for program, members in current_groups.items():
        snap = build_period_snapshot(members)
        prior = build_period_snapshot(previous_groups[program]) if previous_groups.get(program) else None
        health = snap["institution_health"]
        rows.append({
            "name": program, "students": snap["total_students"], "success_rate": snap["success_rate"],
            "average_gpa": snap["average_gpa"], "average_progress": snap["average_progress"],
            "high_risk": snap["high_risk"], "health_score": health,
            "health_status": "Strong" if health >= 85 else "Watch" if health >= 70 else "Action Required",
            "enrollment_change": None if prior is None else snap["total_students"] - prior["total_students"],
            "health_change": None if prior is None else health - prior["institution_health"],
        })
    return sorted(rows, key=lambda r: (r["health_score"], -r["high_risk"], r["name"]))


def generate_alerts(current, previous, programs):
    alerts = []
    def add(priority, title, message): alerts.append({"priority": priority, "title": title, "message": message})
    if previous:
        if current["success_rate"] <= previous["success_rate"] - 5:
            add("High", "Course success declined", f"Course success fell {previous['success_rate'] - current['success_rate']:.1f} percentage points from the prior period.")
        if previous["high_risk"] and current["high_risk"] >= previous["high_risk"] * 1.10:
            add("High", "High-risk population increased", f"High-risk students increased from {previous['high_risk']} to {current['high_risk']}.")
        if current["missing_assignments"] >= max(previous["missing_assignments"] + 5, previous["missing_assignments"] * 1.20):
            add("Moderate", "Missing work is rising", f"Missing assignments increased from {previous['missing_assignments']} to {current['missing_assignments']}.")
        if current["institution_health"] <= previous["institution_health"] - 5:
            add("High", "Institution health weakened", f"The Institution Health Index declined {previous['institution_health'] - current['institution_health']} points.")
    for program in programs:
        if program["health_score"] < 70:
            add("High", f"{program['name']} requires intervention", f"Program health is {program['health_score']}/100 with {program['high_risk']} high-risk students.")
        elif program["success_rate"] < 75:
            add("Moderate", f"{program['name']} course success below benchmark", f"Current course success is {program['success_rate']}%.")
    if not alerts:
        add("Low", "No material deterioration detected", "Current available indicators do not show a threshold-level decline.")
    rank = {"High": 0, "Moderate": 1, "Low": 2}
    return sorted(alerts, key=lambda a: rank[a["priority"]])[:8]


def executive_summary(current, previous, alerts):
    if not previous:
        return "This is the first reporting period with sufficient data for the trend engine. Future periods will provide comparative movement and deterioration alerts."
    movement = current["institution_health"] - previous["institution_health"]
    health_text = "improved" if movement > 0 else "declined" if movement < 0 else "remained stable"
    key_alert = next((a for a in alerts if a["priority"] == "High"), alerts[0])
    return (f"Institution Health {health_text} from {previous['institution_health']} to {current['institution_health']}. "
            f"Course success is {current['success_rate']}% and {current['high_risk']} students are currently high risk. "
            f"Executive attention: {key_alert['title']}. {key_alert['message']}")
