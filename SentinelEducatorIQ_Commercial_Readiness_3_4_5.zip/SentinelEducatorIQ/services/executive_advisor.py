import re
from datetime import datetime

SUPPORTED_QUESTIONS = [
    "What is our institution health score?",
    "What changed from the previous reporting period?",
    "Which programs require executive attention?",
    "What are the highest-priority risks?",
    "How is student success performing?",
    "What is the current data-quality status?",
]


def _fmt(value, suffix=""):
    if value is None:
        return "not available"
    return f"{value}{suffix}"


def _evidence(label, value, source, period):
    return {"label": label, "value": str(value), "source": source, "period": period}


def answer_question(question, payload):
    q = re.sub(r"\s+", " ", (question or "").strip()).lower()
    current = payload["snapshot"]
    previous = payload.get("previous")
    comparisons = payload.get("comparisons", [])
    programs = payload.get("programs", [])
    alerts = payload.get("alerts", [])
    quality = payload.get("data_quality", {})
    period = payload["period"]["name"]
    evidence = []
    confidence = "High"

    if not q:
        return {"answer": "Enter a question about institutional health, trends, programs, risks, student success, or data quality.", "evidence": [], "confidence": "Not assessed", "limitations": "No question was submitted."}

    if any(term in q for term in ["institution health", "health score", "overall health", "how healthy"]):
        score = current.get("institution_health", 0)
        status = "Strong" if score >= 85 else "Stable" if score >= 70 else "Watch" if score >= 55 else "At Risk"
        answer = f"The Institution Health Index is {score}/100 for {period}, placing the institution in the {status} range. Academic performance is {current.get('academic_score', 0)}, degree progress is {current.get('progress_score', 0)}, student-risk resilience is {current.get('risk_score', 0)}, and engagement is {current.get('engagement_score', 0)}."
        evidence = [
            _evidence("Institution Health Index", f"{score}/100", "Governed KPI snapshot", period),
            _evidence("Academic Performance", current.get("academic_score", 0), "Governed KPI snapshot", period),
            _evidence("Degree Progress", current.get("progress_score", 0), "Governed KPI snapshot", period),
            _evidence("Risk Resilience", current.get("risk_score", 0), "Governed KPI snapshot", period),
            _evidence("Engagement", current.get("engagement_score", 0), "Governed KPI snapshot", period),
        ]
    elif any(term in q for term in ["changed", "previous period", "trend", "improved", "declined", "difference"]):
        if not previous:
            answer = f"{period} is currently the baseline reporting period for this authorized scope, so no prior-period comparison is available."
            confidence = "Medium"
        else:
            material = [c for c in comparisons if c.get("delta") not in (None, 0)]
            improving = [c for c in material if c.get("status") == "improving"]
            declining = [c for c in material if c.get("status") == "declining"]
            parts = []
            if improving:
                parts.append("Improving: " + "; ".join(f"{c['label']} ({c['delta']:+g})" for c in improving[:3]))
            if declining:
                parts.append("Needs attention: " + "; ".join(f"{c['label']} ({c['delta']:+g})" for c in declining[:3]))
            answer = f"Compared with the prior reporting period, " + (" ".join(parts) if parts else "the monitored executive KPIs are essentially unchanged.")
            evidence = [_evidence(c["label"], f"{c['current']} vs. {c['previous']} ({c['delta']:+g})", "Period-over-period KPI comparison", period) for c in material[:6]]
    elif any(term in q for term in ["program", "department", "academic unit"]):
        at_risk = [p for p in programs if p.get("health_score", 100) < 70 or p.get("high_risk", 0) > 0]
        ranked = at_risk or programs[:5]
        if ranked:
            names = ", ".join(f"{p['name']} ({p['health_score']}/100)" for p in ranked[:5])
            answer = f"The programs requiring the closest executive review are {names}. Priority should be based on low health scores, elevated high-risk student counts, and declining period-over-period performance."
            evidence = [_evidence(p["name"], f"Health {p['health_score']}; success {p['success_rate']}%; high risk {p['high_risk']}", "Program Intelligence scorecard", period) for p in ranked[:5]]
        else:
            answer = "No program scorecards are available for the selected reporting period and authorized scope."
            confidence = "Low"
    elif any(term in q for term in ["risk", "alert", "attention", "concern", "priority"]):
        if alerts:
            top = alerts[:5]
            answer = "The highest-priority governed signals are: " + " ".join(f"{a['priority']}—{a['title']}: {a['message']}" for a in top)
            evidence = [_evidence(a["title"], a["message"], "Executive alert engine", period) for a in top]
        else:
            answer = f"No threshold-based executive alerts were generated for {period}. Leaders should still review program scorecards and data-quality disclosures before concluding that risk is absent."
    elif any(term in q for term in ["student success", "success rate", "gpa", "degree progress", "high-risk students", "high risk students"]):
        answer = (f"For {period}, course success is {_fmt(current.get('success_rate'), '%')}, average GPA is {_fmt(current.get('average_gpa'))}, "
                  f"average degree progress is {_fmt(current.get('average_progress'), '%')}, and {current.get('high_risk', 0)} students are classified as high risk within your authorized scope.")
        evidence = [
            _evidence("Course Success Rate", f"{current.get('success_rate', 0)}%", "Governed KPI snapshot", period),
            _evidence("Average GPA", current.get("average_gpa", 0), "Governed KPI snapshot", period),
            _evidence("Average Degree Progress", f"{current.get('average_progress', 0)}%", "Governed KPI snapshot", period),
            _evidence("High-Risk Students", current.get("high_risk", 0), "Governed KPI snapshot", period),
        ]
    elif any(term in q for term in ["data quality", "quality score", "source data", "governance", "rejected"]):
        answer = (f"The governed data-quality score is {quality.get('average_quality', 0):.1f}%. The platform has evaluated {quality.get('total_rows', 0)} rows across "
                  f"{quality.get('batches', 0)} import batches; {quality.get('rejected_rows', 0)} rejected rows were excluded from executive calculations.")
        evidence = [
            _evidence("Average Data Quality", f"{quality.get('average_quality', 0):.1f}%", "Institutional Data Quality Center", period),
            _evidence("Evaluated Rows", quality.get("total_rows", 0), "Institutional Data Quality Center", period),
            _evidence("Rejected Rows", quality.get("rejected_rows", 0), "Institutional Data Quality Center", period),
        ]
    else:
        answer = ("I could not map that question to a governed Step 8 analysis. Ask about institution health, period-over-period changes, program performance, executive risks, student success, or data quality. "
                  "The advisor intentionally avoids unsupported answers outside the authorized institutional evidence set.")
        confidence = "Not assessed"

    return {
        "answer": answer,
        "evidence": evidence,
        "confidence": confidence,
        "limitations": "This response uses authorized SentinelEducatorIQ records and deterministic analytics only. It does not use external web data, infer protected characteristics, or replace institutional research and executive judgment.",
        "generated_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }
