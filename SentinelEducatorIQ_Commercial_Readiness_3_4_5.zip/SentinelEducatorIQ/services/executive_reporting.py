from __future__ import annotations

from datetime import datetime
from io import BytesIO
from xml.sax.saxutils import escape
from zipfile import ZipFile, ZIP_DEFLATED

from reportlab.lib import colors
from reportlab.lib.enums import TA_CENTER
from reportlab.lib.pagesizes import letter, landscape
from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Paragraph, Spacer, Table, TableStyle, PageBreak, KeepTogether


def _fmt(value, kind=""):
    if value is None:
        return "-"
    if kind == "percent":
        return f"{value}%"
    if kind == "decimal":
        return f"{float(value):.2f}"
    return str(value)


def build_pdf(report):
    buffer = BytesIO()
    doc = SimpleDocTemplate(buffer, pagesize=landscape(letter), rightMargin=36, leftMargin=36, topMargin=32, bottomMargin=32)
    styles = getSampleStyleSheet()
    styles.add(ParagraphStyle(name="ReportTitle", parent=styles["Title"], fontName="Helvetica-Bold", fontSize=22, leading=26, textColor=colors.HexColor("#0B172A"), alignment=TA_CENTER, spaceAfter=8))
    styles.add(ParagraphStyle(name="Section", parent=styles["Heading2"], fontSize=14, leading=17, textColor=colors.HexColor("#17345E"), spaceBefore=10, spaceAfter=8))
    styles.add(ParagraphStyle(name="Small", parent=styles["BodyText"], fontSize=8.5, leading=11, textColor=colors.HexColor("#667085")))
    styles.add(ParagraphStyle(name="Body2", parent=styles["BodyText"], fontSize=10, leading=14))
    story = [Paragraph("SentinelEducatorIQ Executive Academic Intelligence Report", styles["ReportTitle"]),
             Paragraph(f"{escape(report['institution']['name'])} | {escape(report['period']['name'])} | Generated {datetime.now().strftime('%B %d, %Y %I:%M %p')}", styles["Small"]), Spacer(1, 14)]

    snap = report["snapshot"]
    kpi_data = [["Institution Health", "Course Success", "Average GPA", "Degree Progress", "High-Risk Students", "Data Quality"],
                [str(snap["institution_health"]), f"{snap['success_rate']}%", f"{snap['average_gpa']:.2f}", f"{snap['average_progress']}%", str(snap['high_risk']), f"{report['data_quality']['average_quality']:.1f}%"]]
    kpi = Table(kpi_data, colWidths=[1.55*inch]*6, rowHeights=[0.34*inch, 0.48*inch])
    kpi.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#0B172A")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("BACKGROUND",(0,1),(-1,1),colors.HexColor("#EEF4FF")),("TEXTCOLOR",(0,1),(-1,1),colors.HexColor("#172033")),("FONTNAME",(0,0),(-1,-1),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,0),8),("FONTSIZE",(0,1),(-1,1),16),("ALIGN",(0,0),(-1,-1),"CENTER"),("VALIGN",(0,0),(-1,-1),"MIDDLE"),("GRID",(0,0),(-1,-1),0.5,colors.HexColor("#D7DEEA"))]))
    story.extend([kpi, Spacer(1,14), Paragraph("Executive Summary", styles["Section"]), Paragraph(escape(report["summary"]), styles["Body2"])])

    story.append(Paragraph("Period-over-Period Intelligence", styles["Section"]))
    rows = [["Metric","Current","Previous","Change","Direction"]]
    for item in report["comparisons"]:
        rows.append([item["label"], _fmt(item["current"], item["format"]), _fmt(item["previous"], item["format"]), "-" if item["delta"] is None else f"{item['delta']:+g}", item["direction"]])
    table = Table(rows, colWidths=[2.2*inch,1.15*inch,1.15*inch,1.05*inch,1.8*inch], repeatRows=1)
    table.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17345E")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8.5),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#D7DEEA")),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F7F9FC")]),("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.extend([table, Spacer(1,10)])

    story.append(Paragraph("Executive Alerts", styles["Section"]))
    alert_rows = [["Priority","Alert","Executive Interpretation"]] + [[a["priority"],a["title"],Paragraph(escape(a["message"]),styles["Small"])] for a in report["alerts"]]
    alerts = Table(alert_rows, colWidths=[0.8*inch,2.6*inch,6.0*inch], repeatRows=1)
    alerts.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#17345E")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),8),("GRID",(0,0),(-1,-1),0.4,colors.HexColor("#D7DEEA")),("VALIGN",(0,0),(-1,-1),"TOP")]))
    story.extend([alerts, PageBreak(), Paragraph("Program Intelligence Scorecards", styles["Section"])])
    program_rows = [["Program","Students","Health","Status","Success","Avg GPA","Progress","High Risk","Health Change"]]
    for p in report["programs"]:
        program_rows.append([p["name"],p["students"],p["health_score"],p["health_status"],f"{p['success_rate']}%",f"{p['average_gpa']:.2f}",f"{p['average_progress']}%",p["high_risk"],"Baseline" if p["health_change"] is None else f"{p['health_change']:+g}"])
    programs = Table(program_rows, colWidths=[2.55*inch,.65*inch,.55*inch,1.05*inch,.7*inch,.65*inch,.72*inch,.65*inch,.8*inch], repeatRows=1)
    programs.setStyle(TableStyle([("BACKGROUND",(0,0),(-1,0),colors.HexColor("#0B172A")),("TEXTCOLOR",(0,0),(-1,0),colors.white),("FONTNAME",(0,0),(-1,0),"Helvetica-Bold"),("FONTSIZE",(0,0),(-1,-1),7.5),("GRID",(0,0),(-1,-1),0.35,colors.HexColor("#D7DEEA")),("ROWBACKGROUNDS",(0,1),(-1,-1),[colors.white,colors.HexColor("#F7F9FC")]),("VALIGN",(0,0),(-1,-1),"MIDDLE")]))
    story.extend([programs, Spacer(1,14), Paragraph("Data Governance Disclosure", styles["Section"]), Paragraph(escape(report["data_disclosure"]), styles["Body2"]), Spacer(1,8), Paragraph("Methodology Notice", styles["Section"]), Paragraph(escape(report["methodology"]), styles["Small"])])
    doc.build(story)
    buffer.seek(0)
    return buffer


def _col_letter(n):
    s=""
    while n:
        n, r = divmod(n-1,26); s=chr(65+r)+s
    return s


def _sheet_xml(rows):
    out=['<?xml version="1.0" encoding="UTF-8" standalone="yes"?><worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main"><sheetData>']
    for r_idx,row in enumerate(rows,1):
        out.append(f'<row r="{r_idx}">')
        for c_idx,value in enumerate(row,1):
            ref=f'{_col_letter(c_idx)}{r_idx}'
            if isinstance(value,(int,float)) and not isinstance(value,bool): out.append(f'<c r="{ref}"><v>{value}</v></c>')
            else: out.append(f'<c r="{ref}" t="inlineStr"><is><t>{escape("" if value is None else str(value))}</t></is></c>')
        out.append('</row>')
    out.append('</sheetData></worksheet>')
    return ''.join(out)


def build_xlsx(report):
    sheets=[]
    snap=report['snapshot']
    sheets.append(("Executive Summary", [["SentinelEducatorIQ Executive Academic Intelligence Report"],["Institution",report['institution']['name']],["Reporting Period",report['period']['name']],["Generated",datetime.now().isoformat(timespec='minutes')],[],["Metric","Value"],["Institution Health",snap['institution_health']],["Course Success",snap['success_rate']],["Average GPA",snap['average_gpa']],["Degree Progress",snap['average_progress']],["High-Risk Students",snap['high_risk']],["Missing Assignments",snap['missing_assignments']],["Data Quality",report['data_quality']['average_quality']],[],["Executive Summary",report['summary']],[],["Data Governance Disclosure",report['data_disclosure']],["Methodology",report['methodology']]]))
    sheets.append(("KPI Comparisons", [["Metric","Current","Previous","Delta","Percent Change","Direction"]]+[[x['label'],x['current'],x['previous'],x['delta'],x['percent_change'],x['direction']] for x in report['comparisons']]))
    sheets.append(("Program Scorecards", [["Program","Students","Health Score","Health Status","Success Rate","Average GPA","Degree Progress","High Risk","Enrollment Change","Health Change"]]+[[p['name'],p['students'],p['health_score'],p['health_status'],p['success_rate'],p['average_gpa'],p['average_progress'],p['high_risk'],p['enrollment_change'],p['health_change']] for p in report['programs']]))
    sheets.append(("Executive Alerts", [["Priority","Title","Message"]]+[[a['priority'],a['title'],a['message']] for a in report['alerts']]))
    sheets.append(("Data Quality", [["Completed Imports","Rows Evaluated","Accepted","Rejected","Average Quality"],[report['data_quality']['batches'],report['data_quality']['total_rows'],report['data_quality']['accepted_rows'],report['data_quality']['rejected_rows'],report['data_quality']['average_quality']]]))
    buffer=BytesIO()
    with ZipFile(buffer,'w',ZIP_DEFLATED) as z:
        z.writestr('[Content_Types].xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types"><Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/><Default Extension="xml" ContentType="application/xml"/><Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'+''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1,len(sheets)+1))+'</Types>')
        z.writestr('_rels/.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships"><Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        z.writestr('xl/workbook.xml','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships"><sheets>'+''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_) in enumerate(sheets,1))+'</sheets></workbook>')
        z.writestr('xl/_rels/workbook.xml.rels','<?xml version="1.0" encoding="UTF-8" standalone="yes"?><Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'+''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))+'</Relationships>')
        for i,(_,rows) in enumerate(sheets,1): z.writestr(f'xl/worksheets/sheet{i}.xml',_sheet_xml(rows))
    buffer.seek(0)
    return buffer
