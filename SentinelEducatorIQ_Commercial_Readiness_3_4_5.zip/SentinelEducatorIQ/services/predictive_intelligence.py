from collections import defaultdict
from services.executive_analytics import build_period_snapshot, build_program_scorecards, risk_level, safe_float


def _linear_forecast(values):
    values = [float(v) for v in values]
    n = len(values)
    if not n:
        return 0.0, 0.0
    if n == 1:
        return values[0], 0.0
    xs = list(range(n))
    xbar = sum(xs) / n
    ybar = sum(values) / n
    denom = sum((x - xbar) ** 2 for x in xs) or 1
    slope = sum((x - xbar) * (y - ybar) for x, y in zip(xs, values)) / denom
    return ybar + slope * (n - xbar), slope


def confidence_label(period_count, record_count):
    if period_count >= 4 and record_count >= 100:
        return "High"
    if period_count >= 3 and record_count >= 30:
        return "Moderate"
    return "Preliminary"


def build_institution_forecast(period_series):
    """period_series is chronological: [{period, records, snapshot}, ...]."""
    if not period_series:
        return {}
    snaps = [p["snapshot"] for p in period_series]
    latest = snaps[-1]
    fields = {
        "Enrollment": ("total_students", 0, None, "students"),
        "Course Success": ("success_rate", 0, 100, "%"),
        "Average GPA": ("average_gpa", 0, 4, ""),
        "Degree Progress": ("average_progress", 0, 100, "%"),
        "High-Risk Students": ("high_risk", 0, None, "students"),
        "Institution Health": ("institution_health", 0, 100, "/100"),
    }
    forecasts = []
    for label, (key, lower, upper, unit) in fields.items():
        predicted, slope = _linear_forecast([s.get(key, 0) for s in snaps])
        predicted = max(lower, predicted)
        if upper is not None:
            predicted = min(upper, predicted)
        if key in {"total_students", "high_risk", "institution_health"}:
            predicted = round(predicted)
        elif key == "average_gpa":
            predicted = round(predicted, 2)
        else:
            predicted = round(predicted, 1)
        current = latest.get(key, 0)
        change = round(predicted - current, 2)
        higher_better = key not in {"high_risk"}
        status = "Stable" if abs(change) < .5 else ("Favorable" if (change > 0) == higher_better else "Watch")
        forecasts.append({"metric": label, "current": current, "forecast": predicted, "change": change,
                          "unit": unit, "status": status, "slope": round(slope, 2)})
    record_count = sum(len(p["records"]) for p in period_series)
    return {
        "forecasts": forecasts,
        "confidence": confidence_label(len(period_series), record_count),
        "period_count": len(period_series),
        "record_count": record_count,
        "methodology": "Transparent least-squares trend projection using available reporting-period snapshots. Forecasts are decision-support indicators, not guaranteed outcomes.",
    }


def build_student_risk_predictions(records):
    results = []
    for r in records:
        grade = safe_float(r.get("learn_grade"), 100)
        gpa = safe_float(r.get("gpa"), 4)
        missing = int(safe_float(r.get("missing_assignments_count"), 0))
        attendance = str(r.get("attendance_risk") or "Low").title()
        progress = min(100, safe_float(r.get("completed")) / max(1, safe_float(r.get("required"), 1)) * 100)
        score = 0
        factors = []
        if grade < 60: score += 40; factors.append("course grade below 60%")
        elif grade < 70: score += 28; factors.append("course grade below 70%")
        elif grade < 75: score += 12; factors.append("course grade below 75%")
        if gpa < 2.0: score += 25; factors.append("GPA below 2.0")
        elif gpa < 2.5: score += 12; factors.append("GPA below 2.5")
        if missing >= 5: score += 25; factors.append(f"{missing} missing assignments")
        elif missing >= 2: score += 12; factors.append(f"{missing} missing assignments")
        if attendance == "High": score += 25; factors.append("high attendance risk")
        elif attendance == "Moderate": score += 12; factors.append("moderate attendance risk")
        if progress < 25: score += 5; factors.append("early degree progress")
        probability = min(95, max(5, score))
        band = "High" if probability >= 60 else "Moderate" if probability >= 30 else "Low"
        results.append({"student_id": r.get("id"), "name": r.get("name"), "program": r.get("program"),
                        "probability": probability, "risk_band": band, "factors": factors or ["no material risk factors detected"],
                        "recommended_action": "Immediate advisor outreach and intervention plan" if band == "High" else "Monitor and offer targeted support" if band == "Moderate" else "Continue routine monitoring"})
    return sorted(results, key=lambda x: (-x["probability"], str(x["name"])))


def build_program_viability(period_series):
    latest_records = period_series[-1]["records"] if period_series else []
    prior_records = period_series[-2]["records"] if len(period_series) > 1 else []
    cards = build_program_scorecards(latest_records, prior_records)
    historical = defaultdict(list)
    for item in period_series:
        grouped = defaultdict(list)
        for r in item["records"]:
            grouped[str(r.get("program") or "Unassigned")].append(r)
        for name, members in grouped.items():
            snap = build_period_snapshot(members)
            historical[name].append((snap["total_students"], snap["institution_health"], snap["success_rate"]))
    output = []
    for card in cards:
        hist = historical[card["name"]]
        enrollment_forecast, _ = _linear_forecast([x[0] for x in hist])
        health_forecast, _ = _linear_forecast([x[1] for x in hist])
        viability = round(max(0, min(100, card["health_score"] * .55 + card["success_rate"] * .30 + min(100, max(0, enrollment_forecast / max(1, card["students"]) * 100)) * .15)))
        status = "Sustainable" if viability >= 80 else "Watch" if viability >= 65 else "At Risk"
        drivers = []
        if card["success_rate"] < 75: drivers.append("course success below 75%")
        if card["health_score"] < 70: drivers.append("program health below 70")
        if enrollment_forecast < card["students"]: drivers.append("projected enrollment decline")
        if card["high_risk"] > 0: drivers.append(f"{card['high_risk']} high-risk student(s)")
        output.append({**card, "viability_score": viability, "viability_status": status,
                       "forecast_enrollment": max(0, round(enrollment_forecast)), "forecast_health": max(0, min(100, round(health_forecast))),
                       "drivers": drivers or ["no material deterioration detected"]})
    return sorted(output, key=lambda x: (x["viability_score"], x["name"]))


def executive_prediction_summary(institution_forecast, student_predictions, program_predictions):
    watch = [x for x in institution_forecast.get("forecasts", []) if x["status"] == "Watch"]
    high_students = sum(1 for x in student_predictions if x["risk_band"] == "High")
    at_risk_programs = sum(1 for x in program_predictions if x["viability_status"] == "At Risk")
    key = watch[0]["metric"] if watch else "No institution-level metric"
    return (f"Forecast confidence is {institution_forecast.get('confidence', 'Preliminary').lower()} based on "
            f"{institution_forecast.get('period_count', 0)} reporting period(s). {key} is the leading institution-level watch item. "
            f"{high_students} student prediction(s) are high risk and {at_risk_programs} program(s) are projected at risk.")
