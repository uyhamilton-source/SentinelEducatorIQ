# SentinelEducatorIQ™ Demonstration Guide

The included database contains only fictional, synthetic records for **Hamilton Metropolitan University**.

## Demo accounts

All demonstration accounts use the password `Demo-Executive-2026!`.

| Role | Email |
|---|---|
| Super Administrator | admin@demo.edu |
| President | president@demo.edu |
| Provost | provost@demo.edu |
| Dean | dean.business@demo.edu |
| Program Director | director.it@demo.edu |
| Advisor | advisor@demo.edu |

## Recommended walkthrough

1. Sign in as the President and review the Executive Brief, institutional health trend, risks, opportunities, and accreditation readiness.
2. Open Program Intelligence and drill into a program requiring attention.
3. Open a risk category and then an individual synthetic student record.
4. Open Accreditation & Compliance to review high-risk standards and evidence gaps.
5. Sign in as the Dean or Program Director to demonstrate role-personalized scope.
6. Use Presentation Mode for a board-style executive view.
7. Generate a PDF or Excel executive report.

## Reset the demonstration database

From the project root:

```bash
python scripts/seed_demo.py --reset
```

To create a larger demonstration environment:

```bash
python scripts/seed_demo.py --reset --students 2500
```

Never combine the demonstration database with real institutional data.
