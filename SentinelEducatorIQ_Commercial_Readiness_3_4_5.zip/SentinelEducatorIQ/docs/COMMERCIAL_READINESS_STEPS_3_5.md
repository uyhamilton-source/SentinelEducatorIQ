# Commercial Readiness Implementation: Priorities 3–5

## Priority 3 — Automated testing

Added pytest configuration, coverage configuration, shared fixtures, and initial regression tests for authentication, tenant isolation, health/readiness endpoints, protected routes, and security headers.

Run `pytest` after installing `requirements.txt`. This execution environment could not download Flask from its package repository, so the Flask-dependent suite must be executed in the user's internet-connected VS Code environment or Docker build. Python compilation and database initialization tests passed.

## Priority 4 — PostgreSQL and tenant isolation

Added a dual database compatibility layer. SQLite remains the default for local development. Setting `DATABASE_URL` to a PostgreSQL URL activates psycopg-backed production access. Schema initialization translates SQLite autoincrement declarations for PostgreSQL and supports parameter and conflict syntax conversion.

Authenticated requests now resolve the institution from the signed-in user's stored `institution_id`. Tenant identifiers supplied through a URL or form are not used after authentication. The login form accepts an institution code solely to locate the tenant before credentials are checked.

A first production index migration is included under `migrations/versions/`.

## Priority 5 — Production deployment

Added:

- Dockerfile
- Docker Compose stack
- PostgreSQL 16 service
- Gunicorn configuration
- Nginx reverse proxy
- Application health and readiness endpoints
- Persistent database and upload volumes
- Production environment example
- Ubuntu deployment script
- WSGI entry point

Before a live pilot, configure TLS, encrypted backups, centralized logging, object-storage malware scanning, SSO, and an independent penetration test.
