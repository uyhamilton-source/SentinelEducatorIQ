# SentinelEducatorIQ Step 3 — Executive Trend Intelligence

## Added capabilities
- Persistent `executive_kpi_snapshots` table with one KPI snapshot per institution and reporting period.
- Automatic comparison with the immediately preceding reporting period.
- Period-over-period movement for monitored students, course success, GPA, degree progress, high-risk students, missing assignments, and Institution Health.
- Saved Institution Health trend visualization.
- Threshold-based executive alerts for deterioration in success, risk, missing work, institutional health, and program health.
- Program Intelligence scorecards with program health, success, GPA, degree progress, high-risk counts, enrollment movement, and health movement.
- Automatically generated executive narrative summary.
- Dedicated analytics service layer in `services/executive_analytics.py`.

## Important interpretation note
The current engine uses the data fields presently available in SentinelEducatorIQ. Retention, graduation, faculty, accreditation, enrollment census, and finance indicators remain intentionally excluded until authoritative source data are integrated.

## First run
1. Create and activate a clean virtual environment.
2. Run `pip install -r requirements.txt`.
3. Run `python app.py`.
4. Create at least two reporting periods and import data into both to see comparative trends.

The SQLite schema upgrades automatically on application startup. For production multi-user deployment, migrate the same schema to PostgreSQL and use a formal migration tool such as Alembic.
