# SentinelEducatorIQ Step 7 - Executive Reporting and Board-Ready Exports

## Added
- Executive Reports workspace with reporting-period selection.
- Board-ready PDF export containing KPIs, executive narrative, period comparisons, alerts, program scorecards, methodology, and data-governance disclosure.
- Multi-sheet Excel export containing executive summary, KPI comparisons, program scorecards, alerts, and data-quality metrics.
- Persistent report-generation history with user, reporting period, format, filename, scope, and timestamp.
- Audit events for every generated executive report.
- Role-based report access for super administrators, presidents, provosts, deans, chairs, and program directors.
- Permission-scoped report calculations so leaders only export data they are authorized to view.

## Governance
Reports disclose the number of governed imports, evaluated rows, rejected rows, and average data-quality score. Rejected rows are excluded from executive calculations.

## Run
Install dependencies from `requirements.txt`, set production environment variables described in prior build notes, and run `python app.py`. Existing SQLite databases are upgraded automatically and retained.

## Recommended Step 8
Add an AI Executive Advisor that answers governed natural-language questions using authorized KPI snapshots, program scorecards, alerts, and report history, with evidence citations and no unsupported claims.
