# SentinelEducatorIQ Step 6 — Institutional Data Integration and Quality Center

## Added
- Persistent data-source registry and import lineage.
- Import batches tied to institution, reporting period, source system, user, and filename.
- Row-level validation for required identity fields, numeric ranges, duplicate student/course rows, credit consistency, and missing programs.
- Partial-load behavior: valid records are stored while invalid records are rejected.
- Data-quality score for each import.
- Accepted, rejected, and warning totals.
- Row-level issue explanations for remediation.
- Data Quality Center with source history and validation details.
- Audit linkage from institutional import events to the governed import batch.

## Quality scoring
Each rejected row reduces the score more heavily than a warning. Scores are bounded between 0 and 100 and are intended as an operational quality indicator, not an accreditation standard.

## Run
Use the same setup as Step 5. The SQLite schema upgrades automatically on application startup and existing data is retained.

## Recommended Step 7
Add executive report generation and board-ready PDF/Excel exports using governed KPI snapshots, trend intelligence, program scorecards, alerts, and data-quality disclosures.
