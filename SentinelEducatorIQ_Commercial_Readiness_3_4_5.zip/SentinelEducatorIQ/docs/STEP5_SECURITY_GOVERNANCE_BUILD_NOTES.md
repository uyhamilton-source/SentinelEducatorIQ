# SentinelEducatorIQ Step 5 — Enterprise Security and Governance

## Added
- Persistent institutional security audit trail.
- Audit visibility for sign-ins, sign-outs, password changes, data imports, reporting-period changes, hierarchy changes, user creation, account status changes, and unlock actions.
- Five-attempt account lockout with a 15-minute default lock period.
- Forced password replacement for first-run and newly created accounts.
- Minimum 12-character replacement passwords.
- Secure PBKDF2 password hashing retained from Step 4.
- CSRF validation for every state-changing POST request.
- Hardened session cookies, 30-minute permanent-session lifetime, no-store headers for authenticated pages, upload-size limits, and browser security headers.
- Administrator account activation/deactivation and unlock controls.
- Filterable Security Audit Trail page available to super administrators.

## First launch
Set production values before running:

```bash
SENTINEL_ADMIN_EMAIL=your-admin-email
SENTINEL_ADMIN_PASSWORD=a-strong-temporary-password
SENTINEL_SECRET_KEY=a-long-random-secret
SENTINEL_SECURE_COOKIES=1
```

`SENTINEL_SECURE_COOKIES=1` should be used only when the application is served through HTTPS.

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

The SQLite database upgrades automatically on startup. Existing Step 4 data is retained.

## Validation completed
- Python source compilation.
- Automatic Step 5 schema upgrade.
- Failed-sign-in counter and five-attempt lockout.
- Locked-account rejection.
- Unlock recovery.
- Forced password-change database workflow.
- New-password authentication.
- Audit event persistence and retrieval.
- ZIP archive integrity.

A full Flask browser test could not be executed in the build workspace because external package installation was unavailable. Flask 3.0.3 remains pinned in `requirements.txt`, and the source compiles successfully.

## Production priorities still recommended
- PostgreSQL and Alembic migrations.
- SSO using SAML or OpenID Connect.
- Multifactor authentication.
- Password reset through verified institutional email.
- Centralized logging/SIEM export and configurable retention policies.
- Rate limiting at the reverse proxy and application levels.
- Formal multi-tenant isolation testing.
- Encrypted backups and secrets management.
