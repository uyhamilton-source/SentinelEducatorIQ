# Commercial Package Cleanup

This package contains one authoritative application source tree. Development patch scripts, backup copies, Python caches, runtime uploads, and obsolete temporary files were removed.

The included SQLite database is intentionally retained because it powers the synthetic executive demonstration environment. It contains no real student data.

## Demonstration dataset

- 1 fictional institution
- 1,200 synthetic students
- 18 academic programs
- 4 reporting periods
- 4,800 student-period records
- 25 organizational units
- 6 role-based demonstration users
- 6 accreditation and compliance requirements
- 4 executive KPI snapshots

Use `python scripts/seed_demo.py --reset` to recreate it.
