# SentinelEducatorIQ Step 8 — Governed AI Executive Advisor

## Added
- Natural-language executive question workspace.
- Permission-scoped answers using only authorized institutional records.
- Supported analysis of institution health, period changes, program performance, executive risks, student success, and data quality.
- Evidence cards identifying the metric, value, reporting period, and internal source behind each answer.
- Confidence labels, clear limitations, and refusal to make unsupported claims.
- Persistent user-specific question history.
- Security audit events for every advisor query.
- No external AI service or institutional-data transmission is required for this build.

## Governance
The Step 8 advisor is deterministic and evidence-grounded. It does not infer protected characteristics, browse external sources, or answer outside the governed institutional dataset. It is a decision-support feature and does not replace institutional research validation, accreditation review, or executive judgment.

## Run
Install dependencies from `requirements.txt`, configure the production environment variables from prior build notes, and run `python app.py`. Existing SQLite databases are upgraded automatically and retained.

## Recommended Step 9
Add predictive academic intelligence with transparent forecasting for enrollment, student persistence, course failure, and program viability, including model monitoring, explainability, and human approval controls.
