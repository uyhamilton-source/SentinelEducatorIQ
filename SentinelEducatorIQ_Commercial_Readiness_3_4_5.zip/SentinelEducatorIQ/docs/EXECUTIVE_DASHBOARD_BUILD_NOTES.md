# SentinelEducatorIQ — Step One Build Notes

## What was added

The application home page is now an Executive Academic Command Center rather than a student-card-only advising screen.

The first executive analytics layer now calculates and displays:

- Institution Health Index (initial transparent formula)
- Academic Performance score
- Degree Progress score
- Student Risk score
- Engagement score
- Students monitored and academic-program count
- Current course success rate
- High- and moderate-risk student totals
- Average degree progress
- Executive intervention queue
- Executive signals and completion opportunities
- Program-level risk snapshot

Existing student detail, advising packet, uploads, and program-audit functions remain available.

## Structural corrections

- Added the missing `pathlib.Path` import used by program-audit routes.
- Moved `app.run()` to the true end of `app.py`, ensuring routes declared later in the source are registered when the application is launched directly.
- Preserved backups of the original `app.py` and dashboard template.

## Important data limitation

The first Health Index uses only fields currently available in the application: grades, degree progress, risk, and missing assignments. It does not present unsupported retention, graduation-rate, accreditation, faculty-performance, enrollment, or financial metrics. Those should be added only after source data are integrated.

## Initial Health Index formula

- Academic Performance: 35%
- Degree Progress: 25%
- Student Risk: 25%
- Engagement: 15%

The formula is intentionally visible and should later become configurable by institution, campus, program, and reporting period.

## Clean local setup

Do not reuse the uploaded `venv` folder because Python virtual environments are machine-specific.

```bash
cd SentinelEducatorIQ
python3 -m venv .venv
source .venv/bin/activate       # macOS/Linux
# .venv\\Scripts\\activate      # Windows PowerShell
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

## Recommended next build

Create a persistent institutional data model and reporting-period layer. The current in-memory `students` list is appropriate for a prototype but cannot support multi-campus history, trends, role-based access, auditability, or enterprise reporting.
