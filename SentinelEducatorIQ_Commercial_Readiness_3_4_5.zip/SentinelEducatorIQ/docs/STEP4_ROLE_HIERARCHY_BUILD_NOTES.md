# SentinelEducatorIQ Step 4 — Organizational Hierarchy and Role-Based Access

## Added
- Secure session-based sign-in and sign-out.
- Role permissions for super administrators, presidents, provosts, deans, chairs, program directors, advisors, faculty, and viewers.
- Institution → Campus → College → Department → Program hierarchy.
- User scope assignments and inherited access to descendant units.
- Permission-aware executive dashboard, student records, uploads, reporting periods, audits, hierarchy management, and user administration.
- Automatic program-unit creation and student assignment from imported program data.
- Administration pages for organization units and user accounts.

## First-run administrator
Set these environment variables before first launch:

```
SENTINEL_ADMIN_EMAIL=your-admin-email
SENTINEL_ADMIN_PASSWORD=a-strong-temporary-password
SENTINEL_SECRET_KEY=a-long-random-secret
```

For local demonstration only, the fallback account is:
- Email: `admin@sentineleduiq.local`
- Password: `ChangeMe-Executive-2026!`

Change the fallback values before production deployment.

## Run
```
python -m venv .venv
# Windows: .venv\\Scripts\\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000/login`.

## Production priorities
- Replace SQLite with PostgreSQL.
- Add forced password-change flow, password reset, MFA, SSO/SAML/OIDC, audit logging, account lockout, CSRF protection, and institution-level tenant isolation.
- Add explicit department/program mappings during import rather than relying only on program names.
