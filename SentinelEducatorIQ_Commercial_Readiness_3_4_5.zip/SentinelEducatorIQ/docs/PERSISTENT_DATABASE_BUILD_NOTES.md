# SentinelEducatorIQ Persistent Database and Reporting Period Build

## Added
- SQLite institutional database stored at `instance/sentinel_educator_iq.db`.
- Institution, reporting period, student, and student-period record tables.
- Automatic schema initialization on application startup.
- Current reporting period creation when the database is first initialized.
- Reporting-period administration screen.
- Dashboard period selector.
- Persistent CSV, XLSX, and TXT imports using upsert behavior.
- Period-aware dashboard, student details, advising packets, and program-audit workflow.

## Data behavior
Student identity is stored once in the `students` table. Academic measurements are stored separately in `student_period_records`, allowing the same student to have different grades, risks, credits, and engagement data in each term. Reimporting the same student, period, and course updates that record rather than creating a duplicate.

## Run
```bash
python -m venv .venv
# Windows: .venv\Scripts\activate
# macOS/Linux: source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

The database is created automatically. To store it elsewhere, set `SENTINEL_DATABASE_PATH` to an absolute file path before starting the application.

## Production note
SQLite is appropriate for this development build and controlled pilots. Before multi-campus production deployment, migrate the same relational model to PostgreSQL and add authentication, role-based access control, audit logs, encryption/key management, backups, and formal database migrations.
