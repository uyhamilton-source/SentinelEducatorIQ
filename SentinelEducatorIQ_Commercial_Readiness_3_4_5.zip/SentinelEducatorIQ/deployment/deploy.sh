#!/usr/bin/env bash
set -euo pipefail

if [[ ! -f .env ]]; then
  echo "Missing .env. Copy .env.production.example to .env and set secure values."
  exit 1
fi

docker compose pull
docker compose build --pull
docker compose up -d
docker compose ps
curl --retry 12 --retry-delay 5 --fail http://127.0.0.1/healthz
