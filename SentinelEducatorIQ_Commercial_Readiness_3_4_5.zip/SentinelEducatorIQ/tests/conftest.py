import importlib
import os
import sys
from pathlib import Path

import pytest


@pytest.fixture()
def app(tmp_path, monkeypatch):
    db_path = tmp_path / "sentinel_test.db"
    monkeypatch.setenv("SENTINEL_DATABASE_PATH", str(db_path))
    monkeypatch.setenv("SENTINEL_TESTING", "1")
    monkeypatch.setenv("SENTINEL_SECRET_KEY", "test-secret-key")
    monkeypatch.setenv("SENTINEL_ADMIN_EMAIL", "admin@test.edu")
    monkeypatch.setenv("SENTINEL_ADMIN_PASSWORD", "Test-Executive-2026!")
    monkeypatch.delenv("DATABASE_URL", raising=False)

    for name in ["app", "database", "db_backend"]:
        sys.modules.pop(name, None)
    app_module = importlib.import_module("app")
    app_module.app.config.update(TESTING=True)
    yield app_module.app


@pytest.fixture()
def client(app):
    return app.test_client()


@pytest.fixture()
def login(client):
    def _login(email="admin@test.edu", password="Test-Executive-2026!", institution_code="SENTINEL-DEMO"):
        return client.post(
            "/login",
            data={"email": email, "password": password, "institution_code": institution_code},
            follow_redirects=False,
        )
    return _login
