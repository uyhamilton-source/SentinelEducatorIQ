def test_protected_dashboard_redirects_to_login(client):
    response = client.get("/")
    assert response.status_code == 302
    assert "/login" in response.headers["Location"]


def test_valid_login_creates_session(client, login):
    response = login()
    assert response.status_code == 302
    assert "/account/change-password" in response.headers["Location"] or response.headers["Location"].endswith("/")


def test_invalid_login_is_rejected(client):
    response = client.post(
        "/login",
        data={"institution_code": "SENTINEL-DEMO", "email": "admin@test.edu", "password": "wrong"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Invalid email or password" in response.data
