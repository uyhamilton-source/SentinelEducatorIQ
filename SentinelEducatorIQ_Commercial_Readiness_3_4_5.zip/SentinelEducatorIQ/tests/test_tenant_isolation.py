def test_user_session_is_bound_to_own_institution(app, client):
    from database import connection, generate_password_hash

    with app.app_context():
        with connection() as conn:
            cur = conn.execute("INSERT INTO institutions (name, code) VALUES (?, ?)", ("Second University", "SECOND"))
            second_id = cur.lastrowid
            conn.execute(
                "INSERT INTO users (institution_id,email,full_name,password_hash,role,is_active,must_change_password) VALUES (?,?,?,?,?,1,0)",
                (second_id, "second@test.edu", "Second Admin", generate_password_hash("Second-Executive-2026!"), "super_admin"),
            )
    response = client.post(
        "/login",
        data={"institution_code": "SECOND", "email": "second@test.edu", "password": "Second-Executive-2026!"},
        follow_redirects=True,
    )
    assert response.status_code == 200
    assert b"Second University" in response.data
    assert b"Sentinel Demonstration Institution" not in response.data
