from program_requirements import PROGRAM_REQUIREMENTS

from flask import Flask, render_template, request, redirect, url_for, flash, send_from_directory, send_file, session, g, abort
import os
import re
import csv
from openpyxl import load_workbook
from pathlib import Path
from collections import Counter, defaultdict
from functools import wraps
from database import (
    initialize_database, get_default_institution, get_institution, get_institution_by_code, list_reporting_periods,
    get_reporting_period, create_reporting_period, set_current_period,
    upsert_student_record, fetch_students_for_period, fetch_student,
    get_previous_reporting_period, save_executive_snapshot, list_executive_snapshots,
    initialize_step4, authenticate_user, get_user, user_can, list_organization_units,
    create_organization_unit, list_users, create_user, fetch_students_for_period_scoped,
    sync_student_program_assignments, ROLE_PERMISSIONS, initialize_step5,
    authenticate_user_secure, change_user_password, log_audit_event, list_audit_logs,
    set_user_active, unlock_user, initialize_step6, get_or_create_data_source,
    start_import_batch, add_import_issue, finish_import_batch, list_import_batches,
    list_import_issues, data_quality_summary, initialize_step7, record_executive_report,
    list_executive_reports, initialize_step8, record_advisor_query, list_advisor_queries,
    initialize_step9, record_forecast_run, list_forecast_runs,
    initialize_accreditation, accreditation_summary, list_accreditation_items, create_accreditation_item,
    initialize_executive_experience, get_institution_branding, save_institution_branding,
)
from services.executive_reporting import build_pdf, build_xlsx
from services.executive_advisor import answer_question, SUPPORTED_QUESTIONS
from services.predictive_intelligence import (build_institution_forecast, build_student_risk_predictions,
    build_program_viability, executive_prediction_summary)
from services.executive_analytics import (
    build_period_snapshot, compare_snapshots, build_program_scorecards,
    generate_alerts, executive_summary,
)


def calculate_dashboard_math(student):
    program = student.get("program", "")
    degree = student.get("degree", "")

    if not degree:
        if "Associate" in program or program.startswith("AS ") or program.startswith("AA "):
            degree = "Associate of Science"
        elif "Bachelor" in program or program.startswith("BS ") or program.startswith("BA "):
            degree = "Bachelor of Science"
        elif int(student.get("required", 0) or 0) == 60:
            degree = "Associate Degree"
        elif int(student.get("required", 0) or 0) == 120:
            degree = "Bachelor Degree"
        else:
            degree = "Not listed"

    student["degree"] = degree

    required_credits = PROGRAM_REQUIREMENTS.get(
        program,
        int(student.get("required", 0) or 0)
    )

    completed_credits = int(student.get("completed", 0) or 0)

    # Bachelor students should already have completed associate-level credits.
    # Use 60 credits as the minimum completed-credit floor for bachelor-level programs.
    degree_text = str(student.get("degree", "")).lower()
    program_text = str(student.get("program", "")).lower()

    is_bachelor = (
        "bachelor" in degree_text
        or degree_text.startswith("bs")
        or degree_text.startswith("ba")
        or "bachelor" in program_text
        or program_text.startswith("bs")
        or program_text.startswith("ba")
        or required_credits == 120
    )

    if is_bachelor and completed_credits < 60:
        completed_credits = 60

    missing_courses = student.get("missing_courses", [])

    if isinstance(missing_courses, str):
        missing_courses = [
            course.strip()
            for course in missing_courses.split(";")
            if course.strip()
        ]

    remaining_credits = max(0, required_credits - completed_credits)
    passed_courses = student.get("passed_courses", [])

    if isinstance(passed_courses, str):
        passed_courses = [
            course.strip().upper()
            for course in passed_courses.replace(",", ";").split(";")
            if course.strip()
        ]

    missing_course_credits = 0
    formatted_missing_courses = []

    for course in missing_courses:
        if isinstance(course, dict):
            course_name = course.get("name", "").strip()
            course_credits = int(course.get("credits", 3) or 3)
            course_text = course_name
        else:
            course_text = str(course).strip()
            course_credits = 3

        course_code = course_text.split()[0].upper() if course_text else ""

        # Skip courses already passed/completed
        if course_code in passed_courses:
            continue

        if "—" in course_text:
            course_name = course_text.split("—")[0].strip()
        else:
            course_name = course_text

        missing_course_credits += course_credits
        formatted_missing_courses.append({
            "name": course_name,
            "credits": course_credits
        })

    missing_courses = formatted_missing_courses

    graduation_progress = 0
    if required_credits > 0:
        graduation_progress = round(
            (completed_credits / required_credits) * 100,
            1
        )

    # Final degree correction based on required program credits
    if required_credits == 120:
        degree = "Bachelor of Science"
    elif required_credits == 60:
        degree = "Associate of Science"
    elif not degree or degree == "Not listed":
        degree = "Not listed"

    student["degree"] = degree
    student["required"] = required_credits
    completed_credits = max(0, required_credits - remaining_credits)
    student["completed"] = completed_credits
    # Remaining credits should match known missing course credits
    remaining_credits = missing_course_credits
    student["remaining_credits"] = remaining_credits
    student["missing_courses"] = missing_courses
    student["missing_course_credits"] = missing_course_credits
    student["graduation_progress"] = graduation_progress

    # FINAL CREDIT CORRECTION
    # Remaining credits must equal active missing course credits.
    student["missing_course_credits"] = missing_course_credits
    student["remaining_credits"] = missing_course_credits

    # Degree progress must reflect credits completed after missing courses are removed.
    student["completed"] = max(0, required_credits - missing_course_credits)

    if required_credits > 0:
        student["graduation_progress"] = round(
            (student["completed"] / required_credits) * 100,
            1
        )
    else:
        student["graduation_progress"] = 0

    return student

app = Flask(__name__)
app.config["TESTING"] = os.environ.get("SENTINEL_TESTING", "0") == "1"
app.secret_key = os.environ.get("SENTINEL_SECRET_KEY", "change-this-secret-before-production")
app.config.update(
    SESSION_COOKIE_HTTPONLY=True,
    SESSION_COOKIE_SAMESITE="Lax",
    SESSION_COOKIE_SECURE=os.environ.get("SENTINEL_SECURE_COOKIES", "0") == "1",
    PERMANENT_SESSION_LIFETIME=1800,
    MAX_CONTENT_LENGTH=16 * 1024 * 1024,
)

UPLOAD_FOLDER = "uploads"
os.makedirs(UPLOAD_FOLDER, exist_ok=True)

def login_required(view):
    @wraps(view)
    def wrapped(*args, **kwargs):
        if not g.user:
            return redirect(url_for("login", next=request.path))
        return view(*args, **kwargs)
    return wrapped


def permission_required(permission):
    def decorator(view):
        @wraps(view)
        def wrapped(*args, **kwargs):
            if not g.user:
                return redirect(url_for("login", next=request.path))
            if not user_can(g.user, permission):
                abort(403)
            return view(*args, **kwargs)
        return wrapped
    return decorator


def _csrf_token():
    import secrets
    token = session.get("csrf_token")
    if not token:
        token = secrets.token_urlsafe(32)
        session["csrf_token"] = token
    return token


def _request_metadata():
    return {
        "ip_address": request.headers.get("X-Forwarded-For", request.remote_addr or "").split(",")[0].strip(),
        "user_agent": request.headers.get("User-Agent", "")[:500],
    }


@app.before_request
def load_logged_in_user():
    user_id = session.get("user_id")
    g.user = get_user(user_id) if user_id else None
    _csrf_token()
    if request.method == "POST" and not app.config.get("TESTING"):
        submitted = request.form.get("csrf_token") or request.headers.get("X-CSRF-Token")
        if not submitted or submitted != session.get("csrf_token"):
            abort(400, "Invalid or missing CSRF token.")
    if g.user and g.user.get("must_change_password") and request.endpoint not in {"change_password", "logout", "static"}:
        return redirect(url_for("change_password"))


@app.after_request
def apply_security_headers(response):
    response.headers.setdefault("X-Content-Type-Options", "nosniff")
    response.headers.setdefault("X-Frame-Options", "DENY")
    response.headers.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
    response.headers.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
    response.headers.setdefault("Content-Security-Policy", "default-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; script-src 'self' 'unsafe-inline'")
    if g.get("user"):
        response.headers.setdefault("Cache-Control", "no-store")
    return response


def current_institution():
    """Resolve the tenant from the authenticated user; never trust a URL tenant id."""
    if g.get("user"):
        institution = get_institution(g.user.get("institution_id"))
        if not institution:
            abort(403, "Your institution is not available.")
        return institution
    requested_code = (request.values.get("institution_code") or request.headers.get("X-Institution-Code") or "").strip()
    return get_institution_by_code(requested_code) or get_default_institution()


@app.context_processor
def inject_security_context():
    return {"current_user": g.user, "user_can": lambda permission: user_can(g.user, permission), "csrf_token": _csrf_token}


@app.route("/login", methods=["GET", "POST"])
def login():
    institution = current_institution()
    if request.method == "POST":
        result = authenticate_user_secure(institution["id"], request.form.get("email", ""), request.form.get("password", ""))
        user = result.get("user")
        meta = _request_metadata()
        log_audit_event(institution["id"], "login", user_id=user.get("id") if user else None,
                        outcome=result["status"], details={"email": request.form.get("email", "")}, **meta)
        if result["status"] == "success":
            session.clear()
            session.permanent = True
            session["user_id"] = user["id"]
            session["csrf_token"] = __import__("secrets").token_urlsafe(32)
            if user.get("must_change_password"):
                return redirect(url_for("change_password"))
            return redirect(request.args.get("next") or url_for("dashboard"))
        if result["status"] == "locked":
            flash("This account is temporarily locked after repeated unsuccessful sign-in attempts.")
        else:
            flash("Invalid email or password.")
    return render_template("login.html", institution=institution)


@app.route("/logout", methods=["POST"])
@login_required
def logout():
    institution = current_institution()
    meta = _request_metadata()
    log_audit_event(institution["id"], "logout", user_id=g.user["id"], **meta)
    session.clear()
    return redirect(url_for("login"))


@app.route("/account/change-password", methods=["GET", "POST"])
@login_required
def change_password():
    institution = current_institution()
    if request.method == "POST":
        try:
            new_password = request.form.get("new_password", "")
            if new_password != request.form.get("confirm_password", ""):
                raise ValueError("The new password and confirmation do not match.")
            change_user_password(g.user["id"], request.form.get("current_password", ""), new_password)
            log_audit_event(institution["id"], "password_changed", user_id=g.user["id"], **_request_metadata())
            flash("Your password was changed successfully.")
            return redirect(url_for("dashboard"))
        except ValueError as exc:
            flash(str(exc))
    return render_template("change_password.html", institution=institution)


PROGRAMS = {
    "Associate Degree": [
        "Accounting", "Applied Engineering", "Artificial Intelligence", "Business Administration",
        "Criminal Justice", "Cybersecurity", "Health Services Administration", "Information Technology",
        "Medical Administrative Billing and Coding", "Medical Assisting Science",
        "Network Systems Administration", "Nursing (ASN)", "Paralegal Studies",
        "Radiologic Technology", "Software Engineering", "General Studies"
    ],
    "Bachelor's Degree": [
        "Accounting", "Applied Engineering", "Artificial Intelligence", "Business Administration",
        "Computer Engineering Technology", "Computer Information Systems", "Cybersecurity",
        "Data Analytics", "Digital Forensics and Incident Response", "Finance",
        "Health Information Management", "Health Science", "Homeland Security",
        "Human Resource Management", "Information Technology Management", "Management",
        "Marketing", "Nursing (BSN)", "Psychology", "Public Administration",
        "Software Engineering", "Sport Management"
    ],
    "Master's Degree": [
        "Master of Business Administration (MBA)", "Master of Accountancy",
        "Master of Science in Information Technology Leadership",
        "Master of Science in Cybersecurity", "Master of Science in Criminal Justice",
        "Master of Science in Education", "Master of Public Health",
        "Master of Science in Nursing", "Master of Science in Psychology",
        "Master of Science in Homeland Security", "Master of Science in Management",
        "Master of Science in Health Services Administration"
    ],
    "Education Specialist": ["Educational Leadership, EdS", "Instructional Leadership, EdS"],
    "Doctoral Degree": [
        "PhD in Instructional Design and Technology", "Doctor of Education (EdD)",
        "Doctor of Business Administration (DBA)", "Doctor of Health Science (DHSc)",
        "Doctor of Nursing Practice (DNP)", "Doctor of Criminal Justice (DCJ)",
        "PhD in Psychology", "PhD in Leadership", "Occupational Therapy Doctorate (OTD)"
    ],
    "Certificate": [
        "Cybersecurity", "Educational Leadership", "Healthcare Administration",
        "Information Technology", "Management", "Nursing Specializations", "Project Management"
    ]
}

initialize_executive_experience(initialize_accreditation(initialize_step9(initialize_step8(initialize_step7(initialize_step6(initialize_database()))))))


def clean_value(row, field, default=""):
    value = row.get(field, default)
    if value is None:
        return default
    if isinstance(value, str) and value.strip() == "":
        return default
    return value


ALLOWED_EXTENSIONS = {"csv", "xlsx", "txt"}

def allowed_file(filename):
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def extract_field_from_text(notes, labels, default=""):
    for label in labels:
        pattern = rf"{label}\s*[:\-]\s*(.+)"
        match = re.search(pattern, notes, re.IGNORECASE)
        if match:
            return match.group(1).strip()
    return default

def parse_txt_student(notes):
    name = extract_field_from_text(notes, ["Student Name", "Name", "Student"], "Text Upload Student")
    student_id = extract_field_from_text(notes, ["Student ID", "ID"], "TXT001")
    course_code = extract_field_from_text(notes, ["Course Code", "Course"], "TXT")
    course_name = extract_field_from_text(notes, ["Course Name"], "Advisor Notes Upload")
    grade = extract_field_from_text(notes, ["Current Grade", "Grade", "Learn Grade"], 0)
    gpa = extract_field_from_text(notes, ["GPA"], "")
    attendance = extract_field_from_text(notes, ["Attendance", "Attendance Risk"], "Moderate")
    missing = extract_field_from_text(notes, ["Missing Assignments"], 0)
    instructor = extract_field_from_text(notes, ["Instructor", "Professor"], "")
    credits_completed = extract_field_from_text(notes, ["Credits Completed", "Completed Credits"], 0)
    credits_required = extract_field_from_text(notes, ["Credits Required", "Required Credits", "Total Credits"], 3)

    grade = str(grade).replace("%", "").strip()

    missing_courses = extract_field_from_text(notes, ["Missing Courses", "Missing Classes", "Courses Needed"], "")
    missing_course_list = [c.strip() for c in str(missing_courses).split(";") if c.strip()]
    missing_course_credits = len(missing_course_list) * 3

    return {
        "student_id": student_id,
        "name": name,
        "program": "Information Technology",
        "degree_level": "Bachelor's Degree",
        "gpa": gpa,
        "attendance_risk": attendance,
        "credits_completed": credits_completed,
        "credits_required": credits_required,
        "course_code": course_code,
        "course_name": course_name,
        "instructor": instructor,
        "learn_grade": grade,
        "blackboard_minutes": "",
        "missing_assignments": missing,
        "missing_courses": missing_course_list,
        "missing_course_credits": missing_course_credits,
        "advisor_notes": notes
    }

def read_uploaded_file(filepath):
    ext = filepath.rsplit(".", 1)[1].lower()

    if ext == "csv":
        rows = []
        with open(filepath, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            for row in reader:
                rows.append(row)
        return rows

    if ext == "xlsx":
        workbook = load_workbook(filepath, data_only=True)
        sheet = workbook.active
        all_rows = list(sheet.iter_rows(values_only=True))
        if not all_rows:
            return []
        headers = [str(h).strip() if h else "" for h in all_rows[0]]
        data = []
        for row in all_rows[1:]:
            data.append(dict(zip(headers, row)))
        return data

    if ext == "txt":
        with open(filepath, "r", encoding="utf-8", errors="ignore") as f:
            notes = f.read()
        return [parse_txt_student(notes)]

    return []

def calculate_risk_level(learn_grade, attendance_risk, missing_assignments):
    try:
        grade = float(learn_grade)
    except:
        grade = 100

    try:
        missing = int(float(missing_assignments))
    except:
        missing = 0

    if grade < 60 or attendance_risk == "High" or missing >= 5:
        return "High"
    elif grade < 75 or attendance_risk == "Moderate" or missing >= 2:
        return "Moderate"
    else:
        return "Low"

def build_recommendation(student):
    concerns = []

    if student["attendance_risk"] == "High":
        concerns.append("attendance concerns")

    try:
        if float(student["learn_grade"]) < 70:
            concerns.append("academic performance below benchmark")
    except:
        pass

    try:
        if int(student["missing_assignments_count"]) > 0:
            concerns.append("missing assignments")
    except:
        pass

    if concerns:
        return "Student requires advising due to " + ", ".join(concerns) + ". Student should attend all remaining classes, complete missing coursework, communicate with the instructor, and follow up with advising within 14 days."

    return "Student is currently progressing satisfactorily. Continue monitoring academic performance and engagement."

def _safe_float(value, default=0.0):
    try:
        return float(value)
    except (TypeError, ValueError):
        return default


def _student_risk(student):
    """Return a normalized executive risk level for a student record."""
    explicit = str(student.get("attendance_risk", "")).strip().title()
    calculated = calculate_risk_level(
        student.get("learn_grade", 100),
        explicit or "Low",
        student.get("missing_assignments_count", 0),
    )
    return calculated


def build_executive_dashboard(student_records):
    """Aggregate operational student records into executive-level indicators.

    This is the first analytics layer for SentinelEducatorIQ. The formulas are
    deliberately transparent and can later be replaced with institution-defined
    KPI weights and historical benchmarks.
    """
    records = [calculate_dashboard_math(dict(student)) for student in student_records]
    total = len(records)

    risk_counts = Counter(_student_risk(student) for student in records)
    high_risk = risk_counts.get("High", 0)
    moderate_risk = risk_counts.get("Moderate", 0)
    low_risk = risk_counts.get("Low", 0)

    grades = [_safe_float(s.get("learn_grade"), 0) for s in records if str(s.get("learn_grade", "")).strip() != ""]
    gpas = [_safe_float(s.get("gpa"), 0) for s in records if str(s.get("gpa", "")).strip() != ""]
    progresses = [_safe_float(s.get("graduation_progress"), 0) for s in records]

    average_grade = round(sum(grades) / len(grades), 1) if grades else 0
    average_gpa = round(sum(gpas) / len(gpas), 2) if gpas else 0
    average_progress = round(sum(progresses) / len(progresses), 1) if progresses else 0
    success_rate = round(sum(1 for grade in grades if grade >= 70) / len(grades) * 100, 1) if grades else 0

    missing_assignments = sum(int(_safe_float(s.get("missing_assignments_count"), 0)) for s in records)
    students_near_completion = sum(1 for s in records if _safe_float(s.get("graduation_progress"), 0) >= 75)
    programs = Counter(str(s.get("program") or "Unassigned") for s in records)

    # Initial transparent health formula. It uses only data currently available
    # in the application and avoids claiming retention, enrollment, or compliance
    # measures that have not yet been integrated.
    academic_score = max(0, min(100, average_grade))
    progress_score = max(0, min(100, average_progress))
    risk_score = 100 if total == 0 else max(0, 100 - ((high_risk * 20 + moderate_risk * 8) / total))
    engagement_score = 100 if total == 0 else max(0, 100 - min(100, (missing_assignments / total) * 10))
    institution_health = round(
        academic_score * 0.35
        + progress_score * 0.25
        + risk_score * 0.25
        + engagement_score * 0.15
    )

    if institution_health >= 85:
        health_status = "Strong"
    elif institution_health >= 70:
        health_status = "Watch"
    else:
        health_status = "Action Required"

    program_rows = []
    grouped = defaultdict(list)
    for student in records:
        grouped[str(student.get("program") or "Unassigned")].append(student)

    for program, members in grouped.items():
        member_grades = [_safe_float(m.get("learn_grade"), 0) for m in members]
        program_high_risk = sum(1 for m in members if _student_risk(m) == "High")
        program_rows.append({
            "name": program,
            "students": len(members),
            "average_grade": round(sum(member_grades) / len(member_grades), 1) if member_grades else 0,
            "high_risk": program_high_risk,
            "risk_label": "High" if program_high_risk else "Low",
        })
    program_rows.sort(key=lambda row: (-row["high_risk"], row["average_grade"], row["name"]))

    priority_students = sorted(
        records,
        key=lambda s: (
            {"High": 0, "Moderate": 1, "Low": 2}.get(_student_risk(s), 3),
            _safe_float(s.get("learn_grade"), 100),
        ),
    )[:8]
    for student in priority_students:
        student["executive_risk"] = _student_risk(student)

    return {
        "students": records,
        "total_students": total,
        "high_risk": high_risk,
        "moderate_risk": moderate_risk,
        "low_risk": low_risk,
        "average_grade": average_grade,
        "average_gpa": average_gpa,
        "average_progress": average_progress,
        "success_rate": success_rate,
        "missing_assignments": missing_assignments,
        "students_near_completion": students_near_completion,
        "program_count": len(programs),
        "institution_health": institution_health,
        "health_status": health_status,
        "academic_score": round(academic_score),
        "progress_score": round(progress_score),
        "risk_score": round(risk_score),
        "engagement_score": round(engagement_score),
        "program_rows": program_rows,
        "priority_students": priority_students,
    }


@app.route("/")
@login_required
def dashboard():
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])
    selected_period = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    records = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    context = build_executive_dashboard(records)
    current_snapshot = build_period_snapshot(records)
    has_institution_scope = g.user["role"] in {"super_admin", "president", "provost"}
    if has_institution_scope:
        save_executive_snapshot(institution["id"], selected_period["id"], current_snapshot)
    previous_period = get_previous_reporting_period(institution["id"], selected_period)
    previous_records = fetch_students_for_period_scoped(institution["id"], previous_period["id"], g.user["id"]) if previous_period else []
    previous_snapshot = build_period_snapshot(previous_records) if previous_period else None
    if previous_period and has_institution_scope:
        save_executive_snapshot(institution["id"], previous_period["id"], previous_snapshot)
    comparisons = compare_snapshots(current_snapshot, previous_snapshot)
    program_scorecards = build_program_scorecards(records, previous_records)
    executive_alerts = generate_alerts(current_snapshot, previous_snapshot, program_scorecards)
    history = [dict(row) for row in list_executive_snapshots(institution["id"])] if has_institution_scope else []
    accreditation = accreditation_summary(institution["id"])
    branding = get_institution_branding(institution["id"])
    role = g.user.get("role", "viewer")
    role_focus = {
        "president": {"title": "President's Institutional Brief", "focus": "Institution health, strategic exposure, accreditation readiness, and board-level priorities."},
        "provost": {"title": "Provost's Academic Brief", "focus": "Academic quality, student success, program performance, and faculty-facing priorities."},
        "dean": {"title": "Dean's College Brief", "focus": "Program health, student risk, course success, and improvement actions within your scope."},
        "department_chair": {"title": "Department Leadership Brief", "focus": "Course outcomes, program trends, student interventions, and compliance responsibilities."},
        "program_director": {"title": "Program Director Brief", "focus": "Program health, at-risk students, completion progress, and immediate operating priorities."},
        "advisor": {"title": "Student Success Brief", "focus": "Priority students, completion opportunities, missing work, and advising actions."},
        "faculty": {"title": "Faculty Success Brief", "focus": "Course success, student engagement, priority interventions, and academic progress."},
    }.get(role, {"title": "Executive Institutional Brief", "focus": "Institution health, academic performance, student risk, and priority actions."})
    daily_brief = executive_summary(current_snapshot, previous_snapshot, executive_alerts)
    context.update({
        "institution": institution, "reporting_periods": periods, "selected_period": selected_period,
        "previous_period": previous_period, "previous_snapshot": previous_snapshot,
        "comparisons": comparisons, "program_scorecards": program_scorecards,
        "executive_alerts": executive_alerts,
        "executive_summary_text": executive_summary(current_snapshot, previous_snapshot, executive_alerts),
        "trend_history": history,
        "accreditation": accreditation,
        "branding": branding, "role_focus": role_focus, "daily_brief": daily_brief,
    })
    return render_template("dashboard.html", **context)


def validate_import_row(row, row_number, seen_keys):
    issues = []
    sid = str(clean_value(row, "student_id", "")).strip()
    name = str(clean_value(row, "name", "")).strip()
    program = str(clean_value(row, "program", "")).strip()
    course = str(clean_value(row, "course_code", "")).strip()
    key = (sid, course)
    if not sid:
        issues.append(("student_id", "Error", "REQUIRED_STUDENT_ID", "Student ID is required."))
    if not name:
        issues.append(("name", "Error", "REQUIRED_NAME", "Student name is required."))
    if not program:
        issues.append(("program", "Warning", "MISSING_PROGRAM", "Program is missing and will be assigned as Unassigned."))
    if sid and key in seen_keys:
        issues.append(("student_id", "Error", "DUPLICATE_ROW", "Duplicate student/course record in this file."))
    seen_keys.add(key)
    numeric_rules = [
        ("gpa", 0, 4, "GPA must be between 0 and 4."),
        ("learn_grade", 0, 100, "Learning grade must be between 0 and 100."),
        ("credits_completed", 0, None, "Completed credits cannot be negative."),
        ("credits_required", 1, None, "Required credits must be greater than zero."),
        ("missing_assignments", 0, None, "Missing assignments cannot be negative."),
    ]
    for field, low, high, message in numeric_rules:
        raw = clean_value(row, field, "")
        if raw == "":
            continue
        try:
            value = float(raw)
            if value < low or (high is not None and value > high):
                issues.append((field, "Error", "OUT_OF_RANGE", message))
        except (TypeError, ValueError):
            issues.append((field, "Error", "INVALID_NUMBER", f"{field.replace('_',' ').title()} must be numeric."))
    try:
        if float(clean_value(row, "credits_completed", 0)) > float(clean_value(row, "credits_required", 1)):
            issues.append(("credits_completed", "Warning", "CREDITS_EXCEED_REQUIREMENT", "Completed credits exceed required credits; verify transfer or excess credit data."))
    except (TypeError, ValueError):
        pass
    return sid, issues


@app.route("/upload", methods=["GET", "POST"])
@permission_required("upload")
def upload_report():
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])

    if request.method == "POST":
        file = request.files.get("report")

        if not file or file.filename == "":
            flash("Please select a CSV, Excel, or text file to upload.")
            return redirect(url_for("upload_report"))

        if not allowed_file(file.filename):
            flash("Only CSV, Excel (.xlsx), and text (.txt) files are currently supported.")
            return redirect(url_for("upload_report"))

        filepath = os.path.join(UPLOAD_FOLDER, file.filename)
        file.save(filepath)

        period_id = request.form.get("reporting_period_id", type=int)
        selected_period = get_reporting_period(period_id, institution["id"])
        uploaded_rows = read_uploaded_file(filepath)
        imported_students = []
        source_name = request.form.get("source_name", "Manual Institutional Upload").strip() or "Manual Institutional Upload"
        source_id = get_or_create_data_source(institution["id"], source_name, source_name)
        batch_id = start_import_batch(institution["id"], selected_period["id"], source_id, g.user["id"], file.filename)
        rejected_rows = 0
        warning_count = 0
        seen_keys = set()

        for row_number, row in enumerate(uploaded_rows, start=2):
            student_external_id, issues = validate_import_row(row, row_number, seen_keys)
            for field_name, severity, code, message in issues:
                add_import_issue(batch_id, row_number, student_external_id, field_name, severity, code, message)
            warning_count += sum(1 for issue in issues if issue[1] == "Warning")
            if any(issue[1] == "Error" for issue in issues):
                rejected_rows += 1
                continue
            learn_grade = clean_value(row, "learn_grade", 0)
            attendance_risk = str(clean_value(row, "attendance_risk", "Low")).strip()
            missing_assignments = clean_value(row, "missing_assignments", 0)

            risk_level = calculate_risk_level(learn_grade, attendance_risk, missing_assignments)

            student = {
                "id": str(clean_value(row, "student_id", "")),
                "name": clean_value(row, "name", ""),
                "program": clean_value(row, "program", "Information Technology"),
                "degree_level": clean_value(row, "degree_level", "Bachelor's Degree"),
                "gpa": clean_value(row, "gpa", ""),
                "attendance_risk": risk_level,
                "completed": int(clean_value(row, "credits_completed", 0)),
                "required": int(clean_value(row, "credits_required", 0)) if int(clean_value(row, "credits_required", 0)) > 0 else 1,
                "course_code": clean_value(row, "course_code", ""),
                "course_name": clean_value(row, "course_name", ""),
                "instructor": clean_value(row, "instructor", ""),
                "learn_grade": learn_grade,
                "blackboard_minutes": clean_value(row, "blackboard_minutes", ""),
                "missing_assignments_count": missing_assignments,
                "missing_courses": str(clean_value(row, "missing_courses", "")).split(";") if clean_value(row, "missing_courses", "") else [],
                "missing_course_credits": len(str(clean_value(row, "missing_courses", "")).split(";")) * 3 if clean_value(row, "missing_courses", "") else 0,
                "recommendation": ""
            }

            student["recommendation"] = build_recommendation(student)
            upsert_student_record(institution["id"], selected_period["id"], student, file.filename)
            imported_students.append(student)

        sync_student_program_assignments(institution["id"])
        quality_score = finish_import_batch(batch_id, len(uploaded_rows), len(imported_students), rejected_rows, warning_count)
        log_audit_event(institution["id"], "institutional_data_imported", user_id=g.user["id"], event_category="data", target_type="import_batch", target_id=batch_id, details={"filename": file.filename, "accepted": len(imported_students), "rejected": rejected_rows, "warnings": warning_count, "quality_score": quality_score}, **_request_metadata())
        flash(f"Import completed: {len(imported_students)} accepted, {rejected_rows} rejected, quality score {quality_score}%.")
        return redirect(url_for("data_quality_center", batch_id=batch_id))

    return render_template("upload.html", institution=institution, reporting_periods=periods)



@app.route("/program-intelligence/<path:program_name>")
@permission_required("student_detail")
def program_intelligence_detail(program_name):
    """Executive drill-down from institution metrics to a single academic program."""
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])
    selected_period = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    records = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    program_records = [calculate_dashboard_math(dict(row)) for row in records
                       if str(row.get("program") or "Unassigned") == program_name]
    if not program_records:
        abort(404)

    previous_period = get_previous_reporting_period(institution["id"], selected_period)
    previous_records = fetch_students_for_period_scoped(
        institution["id"], previous_period["id"], g.user["id"]
    ) if previous_period else []
    previous_program_records = [dict(row) for row in previous_records
                                if str(row.get("program") or "Unassigned") == program_name]

    dashboard_data = build_executive_dashboard(program_records)
    scorecards = build_program_scorecards(program_records, previous_program_records)
    scorecard = scorecards[0] if scorecards else None
    risk_groups = {"High": [], "Moderate": [], "Low": []}
    for student in dashboard_data["students"]:
        student["executive_risk"] = _student_risk(student)
        risk_groups[student["executive_risk"]].append(student)

    return render_template(
        "program_intelligence_detail.html",
        institution=institution, reporting_periods=periods, selected_period=selected_period,
        previous_period=previous_period, program_name=program_name, scorecard=scorecard,
        risk_groups=risk_groups, **dashboard_data
    )

@app.route("/student/<student_id>")
@permission_required("student_detail")
def student_detail(student_id):
    institution = current_institution()
    selected_period = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    accessible = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    student = next((row for row in accessible if str(row["id"]) == str(student_id)), None)
    if not student:
        return "Student not found", 404

    remaining = student["required"] - student["completed"]
    progress = round((student["completed"] / student["required"]) * 100, 1)
    return render_template("student.html", student=student, remaining=remaining, progress=progress)

@app.route("/advising-packet/<student_id>")
@permission_required("student_detail")
def advising_packet(student_id):
    institution = current_institution()
    selected_period = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    accessible = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    student = next((row for row in accessible if str(row["id"]) == str(student_id)), None)
    if not student:
        return "Student not found", 404

    remaining = student["required"] - student["completed"]
    progress = round((student["completed"] / student["required"]) * 100, 1)

    return render_template(
        "advising_packet.html",
        student=student,
        remaining=remaining,
        progress=progress,
        programs=PROGRAMS
    )

@app.route("/reporting-periods", methods=["GET", "POST"])
@permission_required("periods")
def reporting_periods():
    institution = current_institution()
    if request.method == "POST":
        try:
            period_id = create_reporting_period(
                institution["id"], request.form["name"], request.form["start_date"],
                request.form["end_date"], request.form.get("period_type", "Term"),
                request.form.get("make_current") == "on",
            )
            log_audit_event(institution["id"], "reporting_period_created", user_id=g.user["id"], event_category="administration", target_type="reporting_period", target_id=period_id, **_request_metadata())
            flash("Reporting period created successfully.")
            return redirect(url_for("dashboard", period_id=period_id))
        except Exception as exc:
            flash(f"Unable to create reporting period: {exc}")
    periods = list_reporting_periods(institution["id"])
    return render_template("reporting_periods.html", institution=institution, reporting_periods=periods)


@app.post("/reporting-periods/<int:period_id>/current")
@permission_required("periods")
def make_reporting_period_current(period_id):
    institution = current_institution()
    set_current_period(institution["id"], period_id)
    log_audit_event(institution["id"], "current_reporting_period_changed", user_id=g.user["id"], event_category="administration", target_type="reporting_period", target_id=period_id, **_request_metadata())
    flash("Current reporting period updated.")
    return redirect(url_for("dashboard", period_id=period_id))


@app.route("/program-audits")
@permission_required("audits")
def program_audits():
    audit_dir = Path("program_audits/forms")
    audit_dir.mkdir(parents=True, exist_ok=True)

    audits = []
    for file in sorted(audit_dir.iterdir()):
        if file.suffix.lower() in [".doc", ".docx", ".pdf"]:
            name = file.stem
            degree = "Bachelor" if "BS" in name or "BA" in name else "Associate" if "AS" in name or "AA" in name else "Not listed"
            audits.append({
                "filename": file.name,
                "name": name,
                "degree": degree
            })

    return render_template("program_audits.html", audits=audits)


@app.route("/program-audits/open/<path:filename>")
@permission_required("audits")
def open_program_audit(filename):
    return send_from_directory("program_audits/forms", filename, as_attachment=True)


@app.route("/student/<student_id>/audit")
@permission_required("audits")
def student_program_audit(student_id):
    institution = current_institution()
    selected_period = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    accessible = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    student = next((row for row in accessible if str(row["id"]) == str(student_id)), None)
    if not student:
        flash("Student not found.")
        return redirect(url_for("dashboard"))

    audit_dir = Path("program_audits/forms")
    audit_dir.mkdir(parents=True, exist_ok=True)

    audits = []
    for file in sorted(audit_dir.iterdir()):
        if file.suffix.lower() in [".doc", ".docx", ".pdf"]:
            audits.append(file.name)

    return render_template("student_program_audit.html", student=student, audits=audits)



@app.route("/administration/hierarchy", methods=["GET", "POST"])
@permission_required("hierarchy")
def organization_hierarchy():
    institution = current_institution()
    if request.method == "POST":
        try:
            create_organization_unit(
                institution["id"], request.form.get("parent_id", type=int),
                request.form["unit_type"], request.form["name"], request.form["code"]
            )
            log_audit_event(institution["id"], "organization_unit_created", user_id=g.user["id"], event_category="administration", details={"name": request.form["name"], "type": request.form["unit_type"]}, **_request_metadata())
            flash("Organization unit created.")
            return redirect(url_for("organization_hierarchy"))
        except Exception as exc:
            flash(f"Unable to create organization unit: {exc}")
    units = list_organization_units(institution["id"])
    return render_template("organization_hierarchy.html", institution=institution, units=units)


@app.route("/administration/users", methods=["GET", "POST"])
@permission_required("users")
def user_administration():
    institution = current_institution()
    if request.method == "POST":
        try:
            create_user(
                institution["id"], request.form["email"], request.form["full_name"],
                request.form["password"], request.form["role"], request.form.get("scope_unit_id", type=int)
            )
            log_audit_event(institution["id"], "user_created", user_id=g.user["id"], event_category="administration", details={"email": request.form["email"], "role": request.form["role"]}, **_request_metadata())
            flash("User account created.")
            return redirect(url_for("user_administration"))
        except Exception as exc:
            flash(f"Unable to create user: {exc}")
    return render_template("users.html", users=list_users(institution["id"]),
                           units=list_organization_units(institution["id"]), roles=ROLE_PERMISSIONS.keys())



def _executive_report_payload(institution, selected_period):
    records = fetch_students_for_period_scoped(institution["id"], selected_period["id"], g.user["id"])
    current = build_period_snapshot(records)
    prior_period = get_previous_reporting_period(institution["id"], selected_period)
    prior_records = fetch_students_for_period_scoped(institution["id"], prior_period["id"], g.user["id"]) if prior_period else []
    prior = build_period_snapshot(prior_records) if prior_period else None
    comparisons = compare_snapshots(current, prior)
    programs = build_program_scorecards(records, prior_records)
    alerts = generate_alerts(current, prior, programs)
    quality = data_quality_summary(institution["id"])
    disclosure = (f"This report is based on {quality['batches']} governed import batch(es), {quality['total_rows']} evaluated rows, "
                  f"and an average data-quality score of {quality['average_quality']:.1f}%. "
                  f"{quality['rejected_rows']} rejected row(s) were excluded from executive calculations.")
    methodology = "Institution Health combines academic performance, degree progress, student risk, and engagement indicators from the selected reporting period. Results are decision-support indicators and do not replace institutional research validation, accreditation review, or professional judgment."
    return {"institution": dict(institution), "period": dict(selected_period), "snapshot": current, "previous": prior,
            "comparisons": comparisons, "programs": programs, "alerts": alerts,
            "summary": executive_summary(current, prior, alerts), "data_quality": quality,
            "data_disclosure": disclosure, "methodology": methodology}




@app.route("/institution-branding", methods=["GET", "POST"])
@permission_required("hierarchy")
def institution_branding():
    institution = current_institution()
    if request.method == "POST":
        saved = save_institution_branding(institution["id"], request.form)
        log_audit_event(institution["id"], "institution_branding_updated", user_id=g.user["id"],
                        event_category="configuration", target_type="institution", target_id=institution["id"],
                        details={"display_name": saved.get("display_name")})
        flash("Institutional branding has been updated.")
        return redirect(url_for("institution_branding"))
    return render_template("institution_branding.html", institution=institution,
                           branding=get_institution_branding(institution["id"]))


@app.route("/accreditation-compliance", methods=["GET", "POST"])
@login_required
@permission_required("audits")
def accreditation_compliance():
    institution = current_institution()
    if request.method == "POST":
        item_id = create_accreditation_item(institution["id"], request.form)
        log_audit_event(institution["id"], "accreditation_item_created", user_id=g.user["id"],
                        event_category="compliance", target_type="accreditation_item", target_id=item_id,
                        details={"standard_code": request.form.get("standard_code"), "title": request.form.get("standard_title")},
                        **_request_metadata())
        flash("Accreditation or compliance requirement added.", "success")
        return redirect(url_for("accreditation_compliance"))
    summary = accreditation_summary(institution["id"])
    return render_template("accreditation_compliance.html", institution=institution, summary=summary, items=summary["items"])

@app.route("/executive-reports")
@permission_required("reports")
def executive_reports():
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])
    selected = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    payload = _executive_report_payload(institution, selected)
    history = list_executive_reports(institution["id"])
    return render_template("executive_reports.html", periods=periods, selected_period=selected, history=history, **payload)


@app.get("/executive-reports/export/<file_format>")
@permission_required("reports")
def export_executive_report(file_format):
    if file_format not in {"pdf", "xlsx"}:
        abort(404)
    institution = current_institution()
    selected = get_reporting_period(request.args.get("period_id", type=int), institution["id"])
    payload = _executive_report_payload(institution, selected)
    safe_period = re.sub(r"[^A-Za-z0-9_-]+", "_", selected["name"]).strip("_")
    filename = f"SentinelEducatorIQ_Executive_Report_{safe_period}.{file_format}"
    content = build_pdf(payload) if file_format == "pdf" else build_xlsx(payload)
    mime = "application/pdf" if file_format == "pdf" else "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    report_id = record_executive_report(institution["id"], selected["id"], g.user["id"], "Board-Ready Executive Report", file_format.upper(), filename, g.user["role"])
    log_audit_event(institution["id"], "executive_report_generated", user_id=g.user["id"], event_category="reporting", target_type="executive_report", target_id=report_id, details={"filename": filename, "format": file_format, "period": selected["name"]}, **_request_metadata())
    return send_file(content, mimetype=mime, as_attachment=True, download_name=filename)



@app.route("/executive-advisor", methods=["GET", "POST"])
@permission_required("advisor")
def executive_advisor():
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])
    selected = get_reporting_period(request.values.get("period_id", type=int), institution["id"])
    payload = _executive_report_payload(institution, selected)
    result = None
    question = ""
    if request.method == "POST":
        question = (request.form.get("question") or "").strip()[:1000]
        result = answer_question(question, payload)
        query_id = record_advisor_query(institution["id"], selected["id"], g.user["id"], question, result, g.user["role"])
        log_audit_event(institution["id"], "executive_advisor_query", user_id=g.user["id"], event_category="analytics",
                        target_type="executive_advisor_query", target_id=query_id,
                        details={"period": selected["name"], "confidence": result.get("confidence")}, **_request_metadata())
    history = list_advisor_queries(institution["id"], user_id=g.user["id"], limit=20)
    return render_template("executive_advisor.html", institution=institution, periods=periods, selected_period=selected,
                           question=question, result=result, suggested_questions=SUPPORTED_QUESTIONS, history=history)

@app.route("/administration/data-quality")
@permission_required("data_quality")
def data_quality_center():
    institution = current_institution()
    batches = list_import_batches(institution["id"], limit=request.args.get("limit", 100, type=int))
    selected_batch_id = request.args.get("batch_id", type=int)
    if not selected_batch_id and batches:
        selected_batch_id = batches[0]["id"]
    issues = list_import_issues(selected_batch_id) if selected_batch_id else []
    return render_template("data_quality.html", institution=institution, batches=batches,
                           selected_batch_id=selected_batch_id, issues=issues,
                           summary=data_quality_summary(institution["id"]))


@app.route("/administration/audit-logs")
@permission_required("audit_logs")
def audit_logs():
    institution = current_institution()
    logs = list_audit_logs(
        institution["id"],
        limit=request.args.get("limit", 250, type=int),
        event_category=request.args.get("category") or None,
        outcome=request.args.get("outcome") or None,
    )
    return render_template("audit_logs.html", institution=institution, logs=logs)


@app.post("/administration/users/<int:user_id>/unlock")
@permission_required("users")
def unlock_user_account(user_id):
    institution = current_institution()
    unlock_user(institution["id"], user_id)
    log_audit_event(institution["id"], "user_unlocked", user_id=g.user["id"],
                    event_category="administration", target_type="user", target_id=user_id,
                    **_request_metadata())
    flash("User account unlocked.")
    return redirect(url_for("user_administration"))


@app.post("/administration/users/<int:user_id>/status")
@permission_required("users")
def change_user_status(user_id):
    institution = current_institution()
    active = request.form.get("active") == "1"
    if user_id == g.user["id"] and not active:
        flash("You cannot deactivate your own account.")
        return redirect(url_for("user_administration"))
    set_user_active(institution["id"], user_id, active)
    log_audit_event(institution["id"], "user_status_changed", user_id=g.user["id"],
                    event_category="administration", target_type="user", target_id=user_id,
                    details={"active": active}, **_request_metadata())
    flash("User status updated.")
    return redirect(url_for("user_administration"))



@app.route("/predictive-intelligence", methods=["GET", "POST"])
@permission_required("predictions")
def predictive_intelligence():
    institution = current_institution()
    periods = list_reporting_periods(institution["id"])
    selected = get_reporting_period(request.args.get("period_id", type=int) or request.form.get("period_id", type=int), institution["id"])
    chronological = [p for p in reversed(periods) if p["start_date"] <= selected["start_date"]]
    period_series = []
    for period in chronological[-6:]:
        records = fetch_students_for_period_scoped(institution["id"], period["id"], g.user["id"])
        if records:
            period_series.append({"period": dict(period), "records": records, "snapshot": build_period_snapshot(records)})
    current_records = period_series[-1]["records"] if period_series else []
    institution_forecast = build_institution_forecast(period_series)
    student_predictions = build_student_risk_predictions(current_records)
    program_predictions = build_program_viability(period_series)
    summary = executive_prediction_summary(institution_forecast, student_predictions, program_predictions)
    if request.method == "POST":
        run_id = record_forecast_run(institution["id"], selected["id"], g.user["id"],
            institution_forecast.get("confidence", "Preliminary"), summary, g.user["role"],
            institution_forecast.get("forecasts", []), student_predictions, program_predictions)
        log_audit_event(institution["id"], "predictive_forecast_generated", user_id=g.user["id"],
            event_category="analytics", target_type="predictive_forecast_run", target_id=run_id,
            details={"period": selected["name"], "confidence": institution_forecast.get("confidence")})
        flash("Predictive forecast snapshot was generated and recorded.", "success")
        return redirect(url_for("predictive_intelligence", period_id=selected["id"]))
    history = list_forecast_runs(institution["id"])
    return render_template("predictive_intelligence.html", institution=institution, periods=periods,
        selected_period=selected, institution_forecast=institution_forecast,
        student_predictions=student_predictions, program_predictions=program_predictions,
        prediction_summary=summary, history=history)

@app.get("/healthz")
def healthz():
    try:
        institution = get_default_institution()
        return {"status": "ok", "service": "SentinelEducatorIQ", "database": "reachable", "institution": institution["code"] if institution else None}, 200
    except Exception:
        return {"status": "degraded", "service": "SentinelEducatorIQ", "database": "unreachable"}, 503


@app.get("/readyz")
def readyz():
    institution = get_default_institution()
    return ({"status": "ready", "institution": institution["code"]}, 200) if institution else ({"status": "not-ready"}, 503)


if __name__ == "__main__":
    app.run(host="0.0.0.0", port=int(os.environ.get("PORT", "5000")), debug=os.environ.get("FLASK_DEBUG", "0") == "1")
