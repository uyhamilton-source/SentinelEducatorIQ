PROGRAM_REQUIREMENTS = {
    # Bachelor degrees: minimum 120 credits
    # Associate degrees: minimum 60 credits
    # Based on KU Undergraduate Catalog 2025-2026.

    "Accounting": 120,
    "Business Administration": 120,
    "Business Analytics": 120,
    "Cinematic Arts": 120,
    "Criminal Justice": 120,
    "Criminal Justice - Forensics": 120,
    "Global Affairs and International Relations": 120,
    "Health Services Administration": 120,
    "Homeland Security": 120,
    "Legal Studies": 120,
    "Political Science": 120,
    "Public Administration": 120,
    "Psychology": 120,

    "Animation and Game Design": 120,
    "Applied Engineering": 120,
    "Artificial Intelligence": 120,
    "Biomedical Sciences": 120,
    "Cloud Engineering": 120,
    "Computer Information Systems": 120,
    "Cybersecurity": 120,
    "Digital Forensics and Incident Response": 120,
    "Health Information Management": 120,
    "Information Systems": 120,
    "Information Technology": 120,
    "Information Technology Management": 120,
    "Management Information Systems": 120,
    "Network Systems and Data Communications": 120,
    "Software Engineering": 120,

    # Associate programs
    "AS Information Technology": 60,
    "Associate of Science in Information Technology": 60,
    "AA General Studies": 60,
    "Associate of Arts in General Studies": 60,
    "AS Cloud and Computing Technology": 60,
    "AS Artificial Intelligence": 60,
    "AS Business Administration": 60,
    "AS Cybersecurity": 60,
    "AS Criminal Justice": 60,
    "AS Graphic Arts and Design": 60,
    "AS Video Game Design": 60,
}
