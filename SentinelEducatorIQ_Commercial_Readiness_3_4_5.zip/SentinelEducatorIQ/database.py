import json
import os
from contextlib import contextmanager
from datetime import date, datetime
from db_backend import connect, database_url, is_postgres

BASE_DIR = os.path.dirname(os.path.abspath(__file__))
DATABASE_PATH = os.environ.get("SENTINEL_DATABASE_PATH", os.path.join(BASE_DIR, "instance", "sentinel_educator_iq.db"))

SCHEMA = """
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS institutions (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    code TEXT NOT NULL UNIQUE,
    timezone TEXT NOT NULL DEFAULT 'America/New_York',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE IF NOT EXISTS reporting_periods (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    period_type TEXT NOT NULL DEFAULT 'Term',
    start_date TEXT NOT NULL,
    end_date TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Open',
    is_current INTEGER NOT NULL DEFAULT 0,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(institution_id, name),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS students (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    external_student_id TEXT NOT NULL,
    name TEXT NOT NULL,
    program TEXT NOT NULL DEFAULT 'Unassigned',
    degree_level TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(institution_id, external_student_id),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_period_records (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    student_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    gpa REAL,
    attendance_risk TEXT NOT NULL DEFAULT 'Low',
    completed_credits INTEGER NOT NULL DEFAULT 0,
    required_credits INTEGER NOT NULL DEFAULT 1,
    course_code TEXT NOT NULL DEFAULT '',
    course_name TEXT NOT NULL DEFAULT '',
    instructor TEXT NOT NULL DEFAULT '',
    learn_grade REAL,
    blackboard_minutes REAL,
    missing_assignments_count INTEGER NOT NULL DEFAULT 0,
    missing_courses_json TEXT NOT NULL DEFAULT '[]',
    recommendation TEXT NOT NULL DEFAULT '',
    source_filename TEXT NOT NULL DEFAULT '',
    imported_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(student_id, reporting_period_id, course_code),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_student_period_records_period ON student_period_records(reporting_period_id);
CREATE INDEX IF NOT EXISTS idx_students_institution ON students(institution_id);

CREATE TABLE IF NOT EXISTS executive_kpi_snapshots (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    total_students INTEGER NOT NULL DEFAULT 0,
    average_grade REAL NOT NULL DEFAULT 0,
    average_gpa REAL NOT NULL DEFAULT 0,
    average_progress REAL NOT NULL DEFAULT 0,
    success_rate REAL NOT NULL DEFAULT 0,
    high_risk INTEGER NOT NULL DEFAULT 0,
    moderate_risk INTEGER NOT NULL DEFAULT 0,
    low_risk INTEGER NOT NULL DEFAULT 0,
    missing_assignments INTEGER NOT NULL DEFAULT 0,
    institution_health INTEGER NOT NULL DEFAULT 0,
    academic_score INTEGER NOT NULL DEFAULT 0,
    progress_score INTEGER NOT NULL DEFAULT 0,
    risk_score INTEGER NOT NULL DEFAULT 0,
    engagement_score INTEGER NOT NULL DEFAULT 0,
    calculated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(institution_id, reporting_period_id),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE,
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id) ON DELETE CASCADE
);
"""


@contextmanager
def connection():
    """Open the configured SQLite or PostgreSQL database transaction."""
    conn = connect(DATABASE_PATH)
    try:
        yield conn
        conn.commit()
    except Exception:
        conn.rollback()
        raise
    finally:
        conn.close()


def initialize_database():
    with connection() as conn:
        conn.executescript(SCHEMA)
        institution = conn.execute("SELECT id FROM institutions ORDER BY id LIMIT 1").fetchone()
        if not institution:
            cursor = conn.execute(
                "INSERT INTO institutions (name, code) VALUES (?, ?)",
                ("Sentinel Demonstration Institution", "SENTINEL-DEMO"),
            )
            institution_id = cursor.lastrowid
        else:
            institution_id = institution["id"]

        current = conn.execute(
            "SELECT id FROM reporting_periods WHERE institution_id = ? AND is_current = 1 LIMIT 1",
            (institution_id,),
        ).fetchone()
        if not current:
            today = date.today()
            year = today.year
            if today.month <= 5:
                name, start, end = f"Spring {year}", f"{year}-01-01", f"{year}-05-31"
            elif today.month <= 8:
                name, start, end = f"Summer {year}", f"{year}-06-01", f"{year}-08-31"
            else:
                name, start, end = f"Fall {year}", f"{year}-09-01", f"{year}-12-31"
            conn.execute(
                "INSERT OR IGNORE INTO reporting_periods (institution_id, name, start_date, end_date, is_current) VALUES (?, ?, ?, ?, 1)",
                (institution_id, name, start, end),
            )
    return institution_id


def get_default_institution():
    """Return the configured/default institution for first-run and login discovery."""
    configured_code = os.environ.get("SENTINEL_DEFAULT_INSTITUTION_CODE", "").strip()
    with connection() as conn:
        if configured_code:
            row = conn.execute(
                "SELECT * FROM institutions WHERE lower(code)=lower(?) LIMIT 1",
                (configured_code,),
            ).fetchone()
            if row:
                return row
        return conn.execute("SELECT * FROM institutions ORDER BY id LIMIT 1").fetchone()


def get_institution(institution_id):
    if not institution_id:
        return None
    with connection() as conn:
        return conn.execute("SELECT * FROM institutions WHERE id=?", (institution_id,)).fetchone()


def get_institution_by_code(code):
    if not code:
        return None
    with connection() as conn:
        return conn.execute(
            "SELECT * FROM institutions WHERE lower(code)=lower(?) LIMIT 1",
            (str(code).strip(),),
        ).fetchone()


def list_institutions():
    with connection() as conn:
        return conn.execute("SELECT * FROM institutions ORDER BY name").fetchall()


def list_reporting_periods(institution_id):
    with connection() as conn:
        return conn.execute(
            "SELECT * FROM reporting_periods WHERE institution_id = ? ORDER BY start_date DESC, id DESC",
            (institution_id,),
        ).fetchall()


def get_reporting_period(period_id, institution_id):
    with connection() as conn:
        if period_id:
            row = conn.execute(
                "SELECT * FROM reporting_periods WHERE id = ? AND institution_id = ?",
                (period_id, institution_id),
            ).fetchone()
            if row:
                return row
        return conn.execute(
            "SELECT * FROM reporting_periods WHERE institution_id = ? ORDER BY is_current DESC, start_date DESC LIMIT 1",
            (institution_id,),
        ).fetchone()


def create_reporting_period(institution_id, name, start_date, end_date, period_type="Term", make_current=False):
    with connection() as conn:
        if make_current:
            conn.execute("UPDATE reporting_periods SET is_current = 0 WHERE institution_id = ?", (institution_id,))
        cursor = conn.execute(
            "INSERT INTO reporting_periods (institution_id, name, period_type, start_date, end_date, is_current) VALUES (?, ?, ?, ?, ?, ?)",
            (institution_id, name.strip(), period_type, start_date, end_date, 1 if make_current else 0),
        )
        return cursor.lastrowid


def set_current_period(institution_id, period_id):
    with connection() as conn:
        conn.execute("UPDATE reporting_periods SET is_current = 0 WHERE institution_id = ?", (institution_id,))
        conn.execute(
            "UPDATE reporting_periods SET is_current = 1 WHERE id = ? AND institution_id = ?",
            (period_id, institution_id),
        )


def upsert_student_record(institution_id, reporting_period_id, student, source_filename=""):
    external_id = str(student.get("id") or "").strip()
    if not external_id:
        raise ValueError("Each imported record requires a student_id.")

    with connection() as conn:
        conn.execute(
            """
            INSERT INTO students (institution_id, external_student_id, name, program, degree_level)
            VALUES (?, ?, ?, ?, ?)
            ON CONFLICT(institution_id, external_student_id) DO UPDATE SET
                name = excluded.name,
                program = excluded.program,
                degree_level = excluded.degree_level,
                updated_at = CURRENT_TIMESTAMP
            """,
            (
                institution_id,
                external_id,
                str(student.get("name") or "Unnamed Student"),
                str(student.get("program") or "Unassigned"),
                str(student.get("degree_level") or ""),
            ),
        )
        student_row = conn.execute(
            "SELECT id FROM students WHERE institution_id = ? AND external_student_id = ?",
            (institution_id, external_id),
        ).fetchone()

        conn.execute(
            """
            INSERT INTO student_period_records (
                student_id, reporting_period_id, gpa, attendance_risk, completed_credits,
                required_credits, course_code, course_name, instructor, learn_grade,
                blackboard_minutes, missing_assignments_count, missing_courses_json,
                recommendation, source_filename
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
            ON CONFLICT(student_id, reporting_period_id, course_code) DO UPDATE SET
                gpa = excluded.gpa,
                attendance_risk = excluded.attendance_risk,
                completed_credits = excluded.completed_credits,
                required_credits = excluded.required_credits,
                course_name = excluded.course_name,
                instructor = excluded.instructor,
                learn_grade = excluded.learn_grade,
                blackboard_minutes = excluded.blackboard_minutes,
                missing_assignments_count = excluded.missing_assignments_count,
                missing_courses_json = excluded.missing_courses_json,
                recommendation = excluded.recommendation,
                source_filename = excluded.source_filename,
                imported_at = CURRENT_TIMESTAMP
            """,
            (
                student_row["id"], reporting_period_id, student.get("gpa") or None,
                student.get("attendance_risk") or "Low", int(student.get("completed") or 0),
                max(1, int(student.get("required") or 1)), str(student.get("course_code") or ""),
                str(student.get("course_name") or ""), str(student.get("instructor") or ""),
                student.get("learn_grade") if student.get("learn_grade") != "" else None,
                student.get("blackboard_minutes") if student.get("blackboard_minutes") != "" else None,
                int(float(student.get("missing_assignments_count") or 0)),
                json.dumps(student.get("missing_courses") or []), str(student.get("recommendation") or ""),
                source_filename,
            ),
        )


def fetch_students_for_period(institution_id, reporting_period_id):
    with connection() as conn:
        rows = conn.execute(
            """
            SELECT s.external_student_id AS id, s.name, s.program, s.degree_level,
                   r.gpa, r.attendance_risk, r.completed_credits AS completed,
                   r.required_credits AS required, r.course_code, r.course_name,
                   r.instructor, r.learn_grade, r.blackboard_minutes,
                   r.missing_assignments_count, r.missing_courses_json,
                   r.recommendation
            FROM student_period_records r
            JOIN students s ON s.id = r.student_id
            WHERE s.institution_id = ? AND r.reporting_period_id = ?
            ORDER BY s.name, r.course_code
            """,
            (institution_id, reporting_period_id),
        ).fetchall()

    records = []
    for row in rows:
        record = dict(row)
        try:
            record["missing_courses"] = json.loads(record.pop("missing_courses_json") or "[]")
        except json.JSONDecodeError:
            record["missing_courses"] = []
        records.append(record)
    return records


def fetch_student(institution_id, external_student_id, reporting_period_id):
    records = fetch_students_for_period(institution_id, reporting_period_id)
    return next((record for record in records if str(record["id"]) == str(external_student_id)), None)


def get_previous_reporting_period(institution_id, selected_period):
    with connection() as conn:
        return conn.execute(
            """SELECT * FROM reporting_periods
               WHERE institution_id = ? AND (start_date < ? OR (start_date = ? AND id < ?))
               ORDER BY start_date DESC, id DESC LIMIT 1""",
            (institution_id, selected_period["start_date"], selected_period["start_date"], selected_period["id"]),
        ).fetchone()


def save_executive_snapshot(institution_id, reporting_period_id, snapshot):
    with connection() as conn:
        conn.execute("""
            INSERT INTO executive_kpi_snapshots (
                institution_id, reporting_period_id, total_students, average_grade, average_gpa,
                average_progress, success_rate, high_risk, moderate_risk, low_risk,
                missing_assignments, institution_health, academic_score, progress_score,
                risk_score, engagement_score, calculated_at
            ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
            ON CONFLICT(institution_id, reporting_period_id) DO UPDATE SET
                total_students=excluded.total_students, average_grade=excluded.average_grade,
                average_gpa=excluded.average_gpa, average_progress=excluded.average_progress,
                success_rate=excluded.success_rate, high_risk=excluded.high_risk,
                moderate_risk=excluded.moderate_risk, low_risk=excluded.low_risk,
                missing_assignments=excluded.missing_assignments,
                institution_health=excluded.institution_health, academic_score=excluded.academic_score,
                progress_score=excluded.progress_score, risk_score=excluded.risk_score,
                engagement_score=excluded.engagement_score, calculated_at=CURRENT_TIMESTAMP
        """, (institution_id, reporting_period_id, snapshot["total_students"], snapshot["average_grade"],
              snapshot["average_gpa"], snapshot["average_progress"], snapshot["success_rate"],
              snapshot["high_risk"], snapshot["moderate_risk"], snapshot["low_risk"],
              snapshot["missing_assignments"], snapshot["institution_health"], snapshot["academic_score"],
              snapshot["progress_score"], snapshot["risk_score"], snapshot["engagement_score"]))


def list_executive_snapshots(institution_id):
    with connection() as conn:
        return conn.execute("""
            SELECT s.*, p.name AS period_name, p.start_date, p.end_date
            FROM executive_kpi_snapshots s JOIN reporting_periods p ON p.id=s.reporting_period_id
            WHERE s.institution_id=? ORDER BY p.start_date, p.id
        """, (institution_id,)).fetchall()

# ---------------------------------------------------------------------------
# Step 4: Organizational hierarchy and role-based access control
# ---------------------------------------------------------------------------
import base64
import hashlib
import hmac
import secrets


def generate_password_hash(password):
    salt = secrets.token_bytes(16)
    iterations = 260000
    digest = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, iterations)
    return f"pbkdf2_sha256${iterations}${base64.b64encode(salt).decode()}${base64.b64encode(digest).decode()}"


def check_password_hash(stored, password):
    try:
        algorithm, iterations, salt_b64, digest_b64 = stored.split("$", 3)
        if algorithm != "pbkdf2_sha256":
            return False
        salt = base64.b64decode(salt_b64)
        expected = base64.b64decode(digest_b64)
        actual = hashlib.pbkdf2_hmac("sha256", password.encode("utf-8"), salt, int(iterations))
        return hmac.compare_digest(expected, actual)
    except (ValueError, TypeError):
        return False

STEP4_SCHEMA = """
CREATE TABLE IF NOT EXISTS organization_units (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    parent_id INTEGER,
    unit_type TEXT NOT NULL,
    name TEXT NOT NULL,
    code TEXT NOT NULL,
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(institution_id, code),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE,
    FOREIGN KEY (parent_id) REFERENCES organization_units(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    email TEXT NOT NULL,
    full_name TEXT NOT NULL,
    password_hash TEXT NOT NULL,
    role TEXT NOT NULL DEFAULT 'viewer',
    is_active INTEGER NOT NULL DEFAULT 1,
    must_change_password INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    last_login_at TEXT,
    UNIQUE(institution_id, email),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS user_scopes (
    user_id INTEGER NOT NULL,
    organization_unit_id INTEGER NOT NULL,
    PRIMARY KEY (user_id, organization_unit_id),
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (organization_unit_id) REFERENCES organization_units(id) ON DELETE CASCADE
);

CREATE TABLE IF NOT EXISTS student_organization_assignments (
    student_id INTEGER NOT NULL,
    organization_unit_id INTEGER NOT NULL,
    is_primary INTEGER NOT NULL DEFAULT 1,
    PRIMARY KEY (student_id, organization_unit_id),
    FOREIGN KEY (student_id) REFERENCES students(id) ON DELETE CASCADE,
    FOREIGN KEY (organization_unit_id) REFERENCES organization_units(id) ON DELETE CASCADE
);

CREATE INDEX IF NOT EXISTS idx_org_units_parent ON organization_units(parent_id);
CREATE INDEX IF NOT EXISTS idx_users_institution ON users(institution_id);
CREATE INDEX IF NOT EXISTS idx_student_org_unit ON student_organization_assignments(organization_unit_id);
"""

ROLE_PERMISSIONS = {
    "super_admin": {"dashboard", "student_detail", "upload", "periods", "hierarchy", "users", "audits", "audit_logs", "data_quality", "reports", "advisor", "predictions"},
    "president": {"dashboard", "student_detail", "periods", "hierarchy", "audits", "data_quality", "reports", "advisor", "predictions"},
    "provost": {"dashboard", "student_detail", "upload", "periods", "hierarchy", "audits", "data_quality", "reports", "advisor", "predictions"},
    "dean": {"dashboard", "student_detail", "upload", "audits", "reports", "advisor", "predictions"},
    "chair": {"dashboard", "student_detail", "upload", "audits", "reports", "advisor", "predictions"},
    "program_director": {"dashboard", "student_detail", "upload", "audits", "reports", "advisor", "predictions"},
    "advisor": {"dashboard", "student_detail", "upload", "audits", "advisor"},
    "faculty": {"dashboard", "student_detail", "advisor"},
    "viewer": {"dashboard", "advisor"},
}


def initialize_step4(institution_id):
    """Create Step 4 tables and a safe first-run hierarchy/account."""
    with connection() as conn:
        conn.executescript(STEP4_SCHEMA)
        institution = conn.execute("SELECT * FROM institutions WHERE id=?", (institution_id,)).fetchone()
        root = conn.execute(
            "SELECT id FROM organization_units WHERE institution_id=? AND unit_type='Institution' LIMIT 1",
            (institution_id,),
        ).fetchone()
        if not root:
            cursor = conn.execute(
                "INSERT INTO organization_units (institution_id, unit_type, name, code) VALUES (?, 'Institution', ?, ?)",
                (institution_id, institution["name"], institution["code"]),
            )
            root_id = cursor.lastrowid
        else:
            root_id = root["id"]

        campus = conn.execute(
            "SELECT id FROM organization_units WHERE institution_id=? AND unit_type='Campus' LIMIT 1",
            (institution_id,),
        ).fetchone()
        if not campus:
            cursor = conn.execute(
                "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'Campus', 'Main Campus', 'MAIN')",
                (institution_id, root_id),
            )
            campus_id = cursor.lastrowid
        else:
            campus_id = campus["id"]

        college = conn.execute(
            "SELECT id FROM organization_units WHERE institution_id=? AND unit_type='College' LIMIT 1",
            (institution_id,),
        ).fetchone()
        if not college:
            cursor = conn.execute(
                "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'College', 'Academic Affairs', 'ACADEMIC')",
                (institution_id, campus_id),
            )
            college_id = cursor.lastrowid
        else:
            college_id = college["id"]

        # Create program units from existing student data and assign students.
        students = conn.execute("SELECT id, program FROM students WHERE institution_id=?", (institution_id,)).fetchall()
        for student in students:
            program_name = (student["program"] or "Unassigned").strip()
            code = "PRG-" + "".join(ch for ch in program_name.upper() if ch.isalnum())[:24]
            unit = conn.execute(
                "SELECT id FROM organization_units WHERE institution_id=? AND code=?",
                (institution_id, code),
            ).fetchone()
            if not unit:
                cursor = conn.execute(
                    "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, 'Program', ?, ?)",
                    (institution_id, college_id, program_name, code),
                )
                unit_id = cursor.lastrowid
            else:
                unit_id = unit["id"]
            conn.execute(
                "INSERT OR IGNORE INTO student_organization_assignments (student_id, organization_unit_id) VALUES (?, ?)",
                (student["id"], unit_id),
            )

        admin_email = os.environ.get("SENTINEL_ADMIN_EMAIL", "admin@sentineleduiq.local").lower()
        admin_password = os.environ.get("SENTINEL_ADMIN_PASSWORD", "ChangeMe-Executive-2026!")
        admin = conn.execute(
            "SELECT id FROM users WHERE institution_id=? AND email=?",
            (institution_id, admin_email),
        ).fetchone()
        if not admin:
            cursor = conn.execute(
                "INSERT INTO users (institution_id, email, full_name, password_hash, role, must_change_password) VALUES (?, ?, ?, ?, 'super_admin', 1)",
                (institution_id, admin_email, "Sentinel Administrator", generate_password_hash(admin_password)),
            )
            conn.execute(
                "INSERT OR IGNORE INTO user_scopes (user_id, organization_unit_id) VALUES (?, ?)",
                (cursor.lastrowid, root_id),
            )


def authenticate_user(institution_id, email, password):
    with connection() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE institution_id=? AND lower(email)=lower(?) AND is_active=1",
            (institution_id, email.strip()),
        ).fetchone()
        if not user or not check_password_hash(user["password_hash"], password):
            return None
        conn.execute("UPDATE users SET last_login_at=CURRENT_TIMESTAMP WHERE id=?", (user["id"],))
        return dict(user)


def get_user(user_id):
    with connection() as conn:
        row = conn.execute("SELECT * FROM users WHERE id=? AND is_active=1", (user_id,)).fetchone()
        return dict(row) if row else None


def user_can(user, permission):
    return bool(user and permission in ROLE_PERMISSIONS.get(user.get("role", "viewer"), set()))


def list_organization_units(institution_id):
    with connection() as conn:
        return conn.execute(
            """SELECT u.*, p.name AS parent_name,
                      (SELECT COUNT(*) FROM student_organization_assignments a WHERE a.organization_unit_id=u.id) AS student_count
               FROM organization_units u LEFT JOIN organization_units p ON p.id=u.parent_id
               WHERE u.institution_id=? ORDER BY
               CASE u.unit_type WHEN 'Institution' THEN 1 WHEN 'Campus' THEN 2 WHEN 'College' THEN 3 WHEN 'Department' THEN 4 ELSE 5 END,
               u.name""",
            (institution_id,),
        ).fetchall()


def create_organization_unit(institution_id, parent_id, unit_type, name, code):
    with connection() as conn:
        cursor = conn.execute(
            "INSERT INTO organization_units (institution_id, parent_id, unit_type, name, code) VALUES (?, ?, ?, ?, ?)",
            (institution_id, parent_id or None, unit_type, name.strip(), code.strip().upper()),
        )
        return cursor.lastrowid


def get_user_scope_unit_ids(user_id):
    with connection() as conn:
        direct = [r["organization_unit_id"] for r in conn.execute(
            "SELECT organization_unit_id FROM user_scopes WHERE user_id=?", (user_id,)
        ).fetchall()]
        if not direct:
            return []
        all_ids = set(direct)
        frontier = list(direct)
        while frontier:
            placeholders = ",".join("?" for _ in frontier)
            children = [r["id"] for r in conn.execute(
                f"SELECT id FROM organization_units WHERE parent_id IN ({placeholders})", frontier
            ).fetchall()]
            frontier = [i for i in children if i not in all_ids]
            all_ids.update(frontier)
        return sorted(all_ids)


def list_users(institution_id):
    with connection() as conn:
        return conn.execute(
            """SELECT u.*, GROUP_CONCAT(o.name, ', ') AS scope_names
               FROM users u LEFT JOIN user_scopes s ON s.user_id=u.id
               LEFT JOIN organization_units o ON o.id=s.organization_unit_id
               WHERE u.institution_id=? GROUP BY u.id ORDER BY u.full_name""",
            (institution_id,),
        ).fetchall()


def create_user(institution_id, email, full_name, password, role, scope_unit_id=None):
    if role not in ROLE_PERMISSIONS:
        raise ValueError("Invalid role")
    with connection() as conn:
        cursor = conn.execute(
            "INSERT INTO users (institution_id, email, full_name, password_hash, role) VALUES (?, ?, ?, ?, ?)",
            (institution_id, email.strip().lower(), full_name.strip(), generate_password_hash(password), role),
        )
        if scope_unit_id:
            conn.execute("INSERT INTO user_scopes (user_id, organization_unit_id) VALUES (?, ?)",
                         (cursor.lastrowid, scope_unit_id))
        return cursor.lastrowid


def fetch_students_for_period_scoped(institution_id, reporting_period_id, user_id=None):
    if not user_id:
        return fetch_students_for_period(institution_id, reporting_period_id)
    unit_ids = get_user_scope_unit_ids(user_id)
    if not unit_ids:
        return []
    placeholders = ",".join("?" for _ in unit_ids)
    with connection() as conn:
        rows = conn.execute(
            f"""SELECT DISTINCT s.external_student_id AS id, s.name, s.program, s.degree_level,
                   r.gpa, r.attendance_risk, r.completed_credits AS completed,
                   r.required_credits AS required, r.course_code, r.course_name,
                   r.instructor, r.learn_grade, r.blackboard_minutes,
                   r.missing_assignments_count, r.missing_courses_json, r.recommendation
               FROM student_period_records r JOIN students s ON s.id=r.student_id
               JOIN student_organization_assignments a ON a.student_id=s.id
               WHERE s.institution_id=? AND r.reporting_period_id=?
                 AND a.organization_unit_id IN ({placeholders})
               ORDER BY s.name, r.course_code""",
            [institution_id, reporting_period_id, *unit_ids],
        ).fetchall()
    records = []
    for row in rows:
        record = dict(row)
        try:
            record["missing_courses"] = json.loads(record.pop("missing_courses_json") or "[]")
        except json.JSONDecodeError:
            record["missing_courses"] = []
        records.append(record)
    return records


def sync_student_program_assignments(institution_id):
    initialize_step4(institution_id)

# ---------------------------------------------------------------------------
# Step 5: Enterprise security, audit logging, and governance controls
# ---------------------------------------------------------------------------
STEP5_SCHEMA = """
CREATE TABLE IF NOT EXISTS audit_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    user_id INTEGER,
    event_type TEXT NOT NULL,
    event_category TEXT NOT NULL DEFAULT 'security',
    outcome TEXT NOT NULL DEFAULT 'success',
    target_type TEXT,
    target_id TEXT,
    details_json TEXT NOT NULL DEFAULT '{}',
    ip_address TEXT,
    user_agent TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE INDEX IF NOT EXISTS idx_audit_institution_created ON audit_logs(institution_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_audit_user_created ON audit_logs(user_id, created_at DESC);
"""


def _column_exists(conn, table_name, column_name):
    if is_postgres(database_url(DATABASE_PATH)):
        row = conn.execute(
            "SELECT 1 FROM information_schema.columns WHERE table_name=? AND column_name=? LIMIT 1",
            (table_name, column_name),
        ).fetchone()
        return bool(row)
    return any(row["name"] == column_name for row in conn.execute(f"PRAGMA table_info({table_name})").fetchall())


def initialize_step5(institution_id):
    initialize_step4(institution_id)
    with connection() as conn:
        conn.executescript(STEP5_SCHEMA)
        additions = {
            "failed_login_count": "INTEGER NOT NULL DEFAULT 0",
            "locked_until": "TEXT",
            "password_changed_at": "TEXT",
            "last_failed_login_at": "TEXT",
        }
        for name, definition in additions.items():
            if not _column_exists(conn, "users", name):
                conn.execute(f"ALTER TABLE users ADD COLUMN {name} {definition}")
    return institution_id


def log_audit_event(institution_id, event_type, user_id=None, event_category="security", outcome="success",
                    target_type=None, target_id=None, details=None, ip_address=None, user_agent=None):
    with connection() as conn:
        conn.execute(
            """INSERT INTO audit_logs
               (institution_id, user_id, event_type, event_category, outcome, target_type, target_id,
                details_json, ip_address, user_agent)
               VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (institution_id, user_id, event_type, event_category, outcome, target_type,
             str(target_id) if target_id is not None else None, json.dumps(details or {}), ip_address, user_agent),
        )


def list_audit_logs(institution_id, limit=250, event_category=None, outcome=None):
    clauses = ["a.institution_id=?"]
    params = [institution_id]
    if event_category:
        clauses.append("a.event_category=?")
        params.append(event_category)
    if outcome:
        clauses.append("a.outcome=?")
        params.append(outcome)
    params.append(max(1, min(int(limit), 1000)))
    with connection() as conn:
        rows = conn.execute(
            f"""SELECT a.*, u.full_name, u.email
                FROM audit_logs a LEFT JOIN users u ON u.id=a.user_id
                WHERE {' AND '.join(clauses)} ORDER BY a.created_at DESC, a.id DESC LIMIT ?""",
            params,
        ).fetchall()
    results = []
    for row in rows:
        item = dict(row)
        try:
            item["details"] = json.loads(item.pop("details_json") or "{}")
        except json.JSONDecodeError:
            item["details"] = {}
        results.append(item)
    return results


def authenticate_user_secure(institution_id, email, password, max_attempts=5, lock_minutes=15):
    from datetime import datetime, timedelta
    normalized = (email or "").strip().lower()
    now = datetime.utcnow()
    with connection() as conn:
        user = conn.execute(
            "SELECT * FROM users WHERE institution_id=? AND lower(email)=lower(?) AND is_active=1",
            (institution_id, normalized),
        ).fetchone()
        if not user:
            return {"status": "invalid", "user": None}
        locked_until = user["locked_until"] if "locked_until" in user.keys() else None
        if locked_until:
            try:
                if datetime.fromisoformat(locked_until) > now:
                    return {"status": "locked", "user": dict(user)}
            except ValueError:
                pass
        if not check_password_hash(user["password_hash"], password or ""):
            failures = int(user["failed_login_count"] or 0) + 1
            new_lock = None
            status = "invalid"
            if failures >= max_attempts:
                new_lock = (now + timedelta(minutes=lock_minutes)).isoformat(timespec="seconds")
                status = "locked"
            conn.execute(
                "UPDATE users SET failed_login_count=?, last_failed_login_at=?, locked_until=? WHERE id=?",
                (failures, now.isoformat(timespec="seconds"), new_lock, user["id"]),
            )
            return {"status": status, "user": dict(user)}
        conn.execute(
            "UPDATE users SET failed_login_count=0, locked_until=NULL, last_login_at=CURRENT_TIMESTAMP WHERE id=?",
            (user["id"],),
        )
        refreshed = conn.execute("SELECT * FROM users WHERE id=?", (user["id"],)).fetchone()
        return {"status": "success", "user": dict(refreshed)}


def change_user_password(user_id, current_password, new_password):
    if len(new_password or "") < 12:
        raise ValueError("New passwords must contain at least 12 characters.")
    with connection() as conn:
        user = conn.execute("SELECT * FROM users WHERE id=? AND is_active=1", (user_id,)).fetchone()
        if not user or not check_password_hash(user["password_hash"], current_password or ""):
            raise ValueError("The current password is incorrect.")
        if check_password_hash(user["password_hash"], new_password):
            raise ValueError("The new password must be different from the current password.")
        conn.execute(
            """UPDATE users SET password_hash=?, must_change_password=0,
               password_changed_at=CURRENT_TIMESTAMP, failed_login_count=0, locked_until=NULL WHERE id=?""",
            (generate_password_hash(new_password), user_id),
        )


def set_user_active(institution_id, user_id, is_active):
    with connection() as conn:
        conn.execute(
            "UPDATE users SET is_active=?, locked_until=NULL, failed_login_count=0 WHERE id=? AND institution_id=?",
            (1 if is_active else 0, user_id, institution_id),
        )


def unlock_user(institution_id, user_id):
    with connection() as conn:
        conn.execute(
            "UPDATE users SET locked_until=NULL, failed_login_count=0 WHERE id=? AND institution_id=?",
            (user_id, institution_id),
        )


# ---------------------------------------------------------------------------
# Step 6: Institutional data integration and quality governance
# ---------------------------------------------------------------------------
STEP6_SCHEMA = """
CREATE TABLE IF NOT EXISTS data_sources (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    name TEXT NOT NULL,
    source_type TEXT NOT NULL DEFAULT 'File Upload',
    system_name TEXT NOT NULL DEFAULT 'Manual Upload',
    is_active INTEGER NOT NULL DEFAULT 1,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    UNIQUE(institution_id, name),
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);
CREATE TABLE IF NOT EXISTS import_batches (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    data_source_id INTEGER,
    user_id INTEGER,
    filename TEXT NOT NULL,
    status TEXT NOT NULL DEFAULT 'Processing',
    total_rows INTEGER NOT NULL DEFAULT 0,
    accepted_rows INTEGER NOT NULL DEFAULT 0,
    rejected_rows INTEGER NOT NULL DEFAULT 0,
    warning_count INTEGER NOT NULL DEFAULT 0,
    quality_score REAL NOT NULL DEFAULT 0,
    started_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    completed_at TEXT,
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE,
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id) ON DELETE CASCADE,
    FOREIGN KEY (data_source_id) REFERENCES data_sources(id) ON DELETE SET NULL,
    FOREIGN KEY (user_id) REFERENCES users(id) ON DELETE SET NULL
);
CREATE TABLE IF NOT EXISTS import_issues (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    import_batch_id INTEGER NOT NULL,
    row_number INTEGER,
    student_external_id TEXT,
    field_name TEXT,
    severity TEXT NOT NULL DEFAULT 'Warning',
    issue_code TEXT NOT NULL,
    message TEXT NOT NULL,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (import_batch_id) REFERENCES import_batches(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_import_batches_institution ON import_batches(institution_id, started_at DESC);
CREATE INDEX IF NOT EXISTS idx_import_issues_batch ON import_issues(import_batch_id, severity);
"""


def initialize_step6(institution_id):
    initialize_step5(institution_id)
    with connection() as conn:
        conn.executescript(STEP6_SCHEMA)
        conn.execute(
            "INSERT OR IGNORE INTO data_sources (institution_id, name, source_type, system_name) VALUES (?, ?, ?, ?)",
            (institution_id, "Manual Institutional Upload", "File Upload", "Manual Upload"),
        )
    return institution_id


def get_or_create_data_source(institution_id, name, system_name="Manual Upload", source_type="File Upload"):
    clean_name = (name or system_name or "Manual Institutional Upload").strip()
    with connection() as conn:
        conn.execute(
            "INSERT OR IGNORE INTO data_sources (institution_id, name, source_type, system_name) VALUES (?, ?, ?, ?)",
            (institution_id, clean_name, source_type, system_name or clean_name),
        )
        return conn.execute(
            "SELECT id FROM data_sources WHERE institution_id=? AND name=?", (institution_id, clean_name)
        ).fetchone()["id"]


def start_import_batch(institution_id, reporting_period_id, data_source_id, user_id, filename):
    with connection() as conn:
        cur = conn.execute(
            """INSERT INTO import_batches
               (institution_id, reporting_period_id, data_source_id, user_id, filename)
               VALUES (?, ?, ?, ?, ?)""",
            (institution_id, reporting_period_id, data_source_id, user_id, filename),
        )
        return cur.lastrowid


def add_import_issue(batch_id, row_number, student_external_id, field_name, severity, issue_code, message):
    with connection() as conn:
        conn.execute(
            """INSERT INTO import_issues
               (import_batch_id, row_number, student_external_id, field_name, severity, issue_code, message)
               VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (batch_id, row_number, student_external_id, field_name, severity, issue_code, message),
        )


def finish_import_batch(batch_id, total_rows, accepted_rows, rejected_rows, warning_count, status="Completed"):
    denominator = max(total_rows, 1)
    quality_score = round(max(0, 100 - ((rejected_rows * 100 + warning_count * 20) / denominator)), 1)
    with connection() as conn:
        conn.execute(
            """UPDATE import_batches SET status=?, total_rows=?, accepted_rows=?, rejected_rows=?,
               warning_count=?, quality_score=?, completed_at=CURRENT_TIMESTAMP WHERE id=?""",
            (status, total_rows, accepted_rows, rejected_rows, warning_count, quality_score, batch_id),
        )
    return quality_score


def list_import_batches(institution_id, limit=100):
    with connection() as conn:
        return conn.execute(
            """SELECT b.*, p.name AS period_name, d.name AS source_name, d.system_name,
                      u.full_name AS imported_by
               FROM import_batches b
               JOIN reporting_periods p ON p.id=b.reporting_period_id
               LEFT JOIN data_sources d ON d.id=b.data_source_id
               LEFT JOIN users u ON u.id=b.user_id
               WHERE b.institution_id=? ORDER BY b.started_at DESC, b.id DESC LIMIT ?""",
            (institution_id, max(1, min(int(limit), 500))),
        ).fetchall()


def list_import_issues(batch_id, limit=500):
    with connection() as conn:
        return conn.execute(
            "SELECT * FROM import_issues WHERE import_batch_id=? ORDER BY row_number, id LIMIT ?",
            (batch_id, max(1, min(int(limit), 2000))),
        ).fetchall()


def data_quality_summary(institution_id):
    with connection() as conn:
        row = conn.execute(
            """SELECT COUNT(*) AS batches, COALESCE(SUM(total_rows),0) AS total_rows,
                      COALESCE(SUM(accepted_rows),0) AS accepted_rows,
                      COALESCE(SUM(rejected_rows),0) AS rejected_rows,
                      COALESCE(SUM(warning_count),0) AS warnings,
                      COALESCE(AVG(quality_score),100) AS average_quality
               FROM import_batches WHERE institution_id=? AND status='Completed'""",
            (institution_id,),
        ).fetchone()
        return dict(row)

STEP7_SCHEMA = """
CREATE TABLE IF NOT EXISTS executive_reports (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    generated_by_user_id INTEGER,
    report_type TEXT NOT NULL,
    file_format TEXT NOT NULL,
    filename TEXT NOT NULL,
    scope_label TEXT,
    generated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id),
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id),
    FOREIGN KEY (generated_by_user_id) REFERENCES users(id)
);
"""

def initialize_step7(institution_id):
    with connection() as conn:
        conn.executescript(STEP7_SCHEMA)
    return institution_id


def record_executive_report(institution_id, reporting_period_id, user_id, report_type, file_format, filename, scope_label=""):
    with connection() as conn:
        cur = conn.execute("""INSERT INTO executive_reports
            (institution_id, reporting_period_id, generated_by_user_id, report_type, file_format, filename, scope_label)
            VALUES (?, ?, ?, ?, ?, ?, ?)""",
            (institution_id, reporting_period_id, user_id, report_type, file_format, filename, scope_label))
        return cur.lastrowid


def list_executive_reports(institution_id, limit=100):
    with connection() as conn:
        return conn.execute("""SELECT r.*, p.name AS period_name, u.full_name AS generated_by
            FROM executive_reports r
            JOIN reporting_periods p ON p.id=r.reporting_period_id
            LEFT JOIN users u ON u.id=r.generated_by_user_id
            WHERE r.institution_id=? ORDER BY r.generated_at DESC LIMIT ?""", (institution_id, limit)).fetchall()

STEP8_SCHEMA = """
CREATE TABLE IF NOT EXISTS executive_advisor_queries (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    user_id INTEGER NOT NULL,
    question TEXT NOT NULL,
    answer TEXT NOT NULL,
    confidence TEXT NOT NULL,
    evidence_json TEXT NOT NULL DEFAULT '[]',
    scope_label TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id),
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id),
    FOREIGN KEY (user_id) REFERENCES users(id)
);
CREATE INDEX IF NOT EXISTS idx_advisor_queries_institution ON executive_advisor_queries(institution_id, created_at DESC);
"""

def initialize_step8(institution_id):
    with connection() as conn:
        conn.executescript(STEP8_SCHEMA)
    return institution_id


def record_advisor_query(institution_id, reporting_period_id, user_id, question, result, scope_label=""):
    with connection() as conn:
        cur = conn.execute("""INSERT INTO executive_advisor_queries
            (institution_id, reporting_period_id, user_id, question, answer, confidence, evidence_json, scope_label)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?)""",
            (institution_id, reporting_period_id, user_id, question, result.get("answer", ""), result.get("confidence", ""),
             json.dumps(result.get("evidence", [])), scope_label))
        return cur.lastrowid


def list_advisor_queries(institution_id, user_id=None, limit=50):
    with connection() as conn:
        sql = """SELECT q.*, p.name AS period_name, u.full_name
                 FROM executive_advisor_queries q
                 JOIN reporting_periods p ON p.id=q.reporting_period_id
                 JOIN users u ON u.id=q.user_id
                 WHERE q.institution_id=?"""
        params = [institution_id]
        if user_id:
            sql += " AND q.user_id=?"
            params.append(user_id)
        sql += " ORDER BY q.created_at DESC LIMIT ?"
        params.append(limit)
        rows = conn.execute(sql, params).fetchall()
        result = []
        for row in rows:
            item = dict(row)
            item["evidence"] = json.loads(item.pop("evidence_json") or "[]")
            result.append(item)
        return result

STEP9_SCHEMA = """
CREATE TABLE IF NOT EXISTS predictive_forecast_runs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    reporting_period_id INTEGER NOT NULL,
    generated_by_user_id INTEGER NOT NULL,
    scope_label TEXT,
    confidence TEXT NOT NULL,
    methodology_version TEXT NOT NULL DEFAULT 'Transparent Trend Model v1.0',
    summary TEXT,
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id),
    FOREIGN KEY (reporting_period_id) REFERENCES reporting_periods(id),
    FOREIGN KEY (generated_by_user_id) REFERENCES users(id)
);
CREATE TABLE IF NOT EXISTS predictive_forecast_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    forecast_run_id INTEGER NOT NULL,
    prediction_type TEXT NOT NULL,
    subject_key TEXT,
    subject_label TEXT,
    current_value REAL,
    predicted_value REAL,
    risk_level TEXT,
    confidence TEXT,
    factors_json TEXT NOT NULL DEFAULT '[]',
    recommended_action TEXT,
    FOREIGN KEY (forecast_run_id) REFERENCES predictive_forecast_runs(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_forecast_runs_inst ON predictive_forecast_runs(institution_id, created_at DESC);
CREATE INDEX IF NOT EXISTS idx_forecast_items_run ON predictive_forecast_items(forecast_run_id);
"""

def initialize_step9(institution_id):
    with connection() as conn:
        conn.executescript(STEP9_SCHEMA)
    return institution_id


def record_forecast_run(institution_id, reporting_period_id, user_id, confidence, summary, scope_label, institution_forecasts, student_predictions, program_predictions):
    with connection() as conn:
        cur = conn.execute("""INSERT INTO predictive_forecast_runs
            (institution_id, reporting_period_id, generated_by_user_id, scope_label, confidence, summary)
            VALUES (?, ?, ?, ?, ?, ?)""", (institution_id, reporting_period_id, user_id, scope_label, confidence, summary))
        run_id = cur.lastrowid
        for item in institution_forecasts:
            conn.execute("""INSERT INTO predictive_forecast_items
                (forecast_run_id, prediction_type, subject_key, subject_label, current_value, predicted_value, risk_level, confidence, factors_json, recommended_action)
                VALUES (?, 'institution_metric', ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run_id, item['metric'], item['metric'], item['current'], item['forecast'], item['status'], confidence,
                 json.dumps([f"Historical slope: {item['slope']}"]), "Review trend and validate assumptions with institutional research."))
        for item in student_predictions:
            conn.execute("""INSERT INTO predictive_forecast_items
                (forecast_run_id, prediction_type, subject_key, subject_label, current_value, predicted_value, risk_level, confidence, factors_json, recommended_action)
                VALUES (?, 'student_risk', ?, ?, NULL, ?, ?, ?, ?, ?)""",
                (run_id, str(item['student_id']), item['name'], item['probability'], item['risk_band'], confidence,
                 json.dumps(item['factors']), item['recommended_action']))
        for item in program_predictions:
            conn.execute("""INSERT INTO predictive_forecast_items
                (forecast_run_id, prediction_type, subject_key, subject_label, current_value, predicted_value, risk_level, confidence, factors_json, recommended_action)
                VALUES (?, 'program_viability', ?, ?, ?, ?, ?, ?, ?, ?)""",
                (run_id, item['name'], item['name'], item['health_score'], item['viability_score'], item['viability_status'], confidence,
                 json.dumps(item['drivers']), "Review enrollment, course success, and student-risk interventions."))
        return run_id


def list_forecast_runs(institution_id, limit=50):
    with connection() as conn:
        return conn.execute("""SELECT r.*, p.name AS period_name, u.full_name AS generated_by
            FROM predictive_forecast_runs r JOIN reporting_periods p ON p.id=r.reporting_period_id
            LEFT JOIN users u ON u.id=r.generated_by_user_id
            WHERE r.institution_id=? ORDER BY r.created_at DESC LIMIT ?""", (institution_id, limit)).fetchall()

ACCREDITATION_SCHEMA = """
CREATE TABLE IF NOT EXISTS accreditation_items (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    institution_id INTEGER NOT NULL,
    accreditor TEXT NOT NULL,
    standard_code TEXT NOT NULL,
    standard_title TEXT NOT NULL,
    category TEXT NOT NULL DEFAULT 'Accreditation',
    owner TEXT NOT NULL DEFAULT '',
    due_date TEXT,
    status TEXT NOT NULL DEFAULT 'In Progress',
    readiness_score INTEGER NOT NULL DEFAULT 0,
    evidence_required INTEGER NOT NULL DEFAULT 0,
    evidence_complete INTEGER NOT NULL DEFAULT 0,
    risk_level TEXT NOT NULL DEFAULT 'Moderate',
    notes TEXT NOT NULL DEFAULT '',
    created_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);
CREATE INDEX IF NOT EXISTS idx_accreditation_items_inst ON accreditation_items(institution_id, due_date);
"""


def initialize_accreditation(institution_id):
    with connection() as conn:
        conn.executescript(ACCREDITATION_SCHEMA)
        count = conn.execute("SELECT COUNT(*) FROM accreditation_items WHERE institution_id=?", (institution_id,)).fetchone()[0]
        if count == 0:
            defaults = [
                ("Institutional Accreditor", "2.1", "Institutional effectiveness and continuous improvement", "Accreditation", "Office of Institutional Effectiveness", "2026-12-15", "In Progress", 82, 10, 8, "Moderate", "Confirm annual assessment evidence and improvement actions."),
                ("Institutional Accreditor", "6.2", "Faculty qualifications and sufficiency", "Academic Compliance", "Office of Academic Affairs", "2026-10-31", "At Risk", 68, 12, 7, "High", "Several faculty qualification files require updated documentation."),
                ("Federal", "Title IV", "Student financial-aid administrative capability", "Federal Compliance", "Financial Aid", "2027-03-01", "On Track", 94, 8, 8, "Low", "Quarterly review is current."),
                ("Institutional", "SLO Cycle", "Student learning outcomes assessment completion", "Academic Compliance", "Assessment Office", "2026-09-30", "In Progress", 76, 15, 11, "Moderate", "Three programs have incomplete closing-the-loop documentation."),
            ]
            conn.executemany("""INSERT INTO accreditation_items
                (institution_id, accreditor, standard_code, standard_title, category, owner, due_date, status,
                 readiness_score, evidence_required, evidence_complete, risk_level, notes)
                VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
                [(institution_id, *row) for row in defaults])
    return institution_id


def list_accreditation_items(institution_id):
    with connection() as conn:
        return conn.execute("""SELECT * FROM accreditation_items WHERE institution_id=?
            ORDER BY CASE risk_level WHEN 'High' THEN 1 WHEN 'Moderate' THEN 2 ELSE 3 END,
                     COALESCE(due_date, '9999-12-31'), standard_code""", (institution_id,)).fetchall()


def accreditation_summary(institution_id):
    items = [dict(row) for row in list_accreditation_items(institution_id)]
    total = len(items)
    if not total:
        return {"items": [], "total": 0, "readiness": 100, "high_risk": 0, "due_soon": 0,
                "evidence_completion": 100, "status": "Ready"}
    today = date.today()
    due_soon = 0
    for item in items:
        try:
            due = date.fromisoformat(item.get("due_date") or "")
            if 0 <= (due - today).days <= 90:
                due_soon += 1
        except ValueError:
            pass
    readiness = round(sum(int(i.get("readiness_score") or 0) for i in items) / total)
    high_risk = sum(1 for i in items if i.get("risk_level") == "High" or i.get("status") == "At Risk")
    required = sum(int(i.get("evidence_required") or 0) for i in items)
    complete = sum(int(i.get("evidence_complete") or 0) for i in items)
    evidence_completion = round((complete / required) * 100) if required else 100
    status = "At Risk" if high_risk else ("Needs Attention" if readiness < 80 or due_soon else "Ready")
    return {"items": items, "total": total, "readiness": readiness, "high_risk": high_risk,
            "due_soon": due_soon, "evidence_completion": evidence_completion, "status": status}


def create_accreditation_item(institution_id, data):
    with connection() as conn:
        cur = conn.execute("""INSERT INTO accreditation_items
            (institution_id, accreditor, standard_code, standard_title, category, owner, due_date, status,
             readiness_score, evidence_required, evidence_complete, risk_level, notes)
            VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)""",
            (institution_id, data.get("accreditor", "Institutional"), data.get("standard_code", ""),
             data.get("standard_title", ""), data.get("category", "Accreditation"), data.get("owner", ""),
             data.get("due_date") or None, data.get("status", "In Progress"), int(data.get("readiness_score") or 0),
             int(data.get("evidence_required") or 0), int(data.get("evidence_complete") or 0),
             data.get("risk_level", "Moderate"), data.get("notes", "")))
        return cur.lastrowid


BRANDING_SCHEMA = """
CREATE TABLE IF NOT EXISTS institution_branding (
    institution_id INTEGER PRIMARY KEY,
    display_name TEXT NOT NULL DEFAULT '',
    logo_url TEXT NOT NULL DEFAULT '',
    primary_color TEXT NOT NULL DEFAULT '#0b172a',
    secondary_color TEXT NOT NULL DEFAULT '#2563eb',
    accent_color TEXT NOT NULL DEFAULT '#d4a72c',
    platform_subtitle TEXT NOT NULL DEFAULT 'Executive Academic Intelligence Platform',
    powered_by_text TEXT NOT NULL DEFAULT 'Powered by Sentinel Intelligence',
    updated_at TEXT NOT NULL DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (institution_id) REFERENCES institutions(id) ON DELETE CASCADE
);
"""

def initialize_executive_experience(institution_id):
    with connection() as conn:
        conn.executescript(BRANDING_SCHEMA)
        conn.execute("""INSERT OR IGNORE INTO institution_branding
            (institution_id, display_name) SELECT id, name FROM institutions WHERE id=?""", (institution_id,))
    return institution_id


def get_institution_branding(institution_id):
    with connection() as conn:
        row=conn.execute("SELECT * FROM institution_branding WHERE institution_id=?", (institution_id,)).fetchone()
        return dict(row) if row else {
            'institution_id': institution_id, 'display_name':'', 'logo_url':'',
            'primary_color':'#0b172a','secondary_color':'#2563eb','accent_color':'#d4a72c',
            'platform_subtitle':'Executive Academic Intelligence Platform',
            'powered_by_text':'Powered by Sentinel Intelligence'
        }


def save_institution_branding(institution_id, data):
    def color(value, fallback):
        value=(value or '').strip()
        return value if len(value)==7 and value.startswith('#') else fallback
    with connection() as conn:
        conn.execute("""INSERT INTO institution_branding
          (institution_id, display_name, logo_url, primary_color, secondary_color, accent_color,
           platform_subtitle, powered_by_text, updated_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, CURRENT_TIMESTAMP)
          ON CONFLICT(institution_id) DO UPDATE SET
           display_name=excluded.display_name, logo_url=excluded.logo_url,
           primary_color=excluded.primary_color, secondary_color=excluded.secondary_color,
           accent_color=excluded.accent_color, platform_subtitle=excluded.platform_subtitle,
           powered_by_text=excluded.powered_by_text, updated_at=CURRENT_TIMESTAMP""",
          (institution_id, (data.get('display_name') or '').strip(), (data.get('logo_url') or '').strip(),
           color(data.get('primary_color'),'#0b172a'), color(data.get('secondary_color'),'#2563eb'),
           color(data.get('accent_color'),'#d4a72c'),
           (data.get('platform_subtitle') or 'Executive Academic Intelligence Platform').strip(),
           (data.get('powered_by_text') or 'Powered by Sentinel Intelligence').strip()))
    return get_institution_branding(institution_id)
