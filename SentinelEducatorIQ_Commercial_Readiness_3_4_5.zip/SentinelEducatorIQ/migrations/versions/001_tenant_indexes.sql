-- Tenant safety and production query indexes.
CREATE INDEX IF NOT EXISTS idx_reporting_periods_institution ON reporting_periods(institution_id);
CREATE INDEX IF NOT EXISTS idx_students_institution_external ON students(institution_id, external_student_id);
CREATE INDEX IF NOT EXISTS idx_users_institution_email ON users(institution_id, email);
CREATE INDEX IF NOT EXISTS idx_accreditation_institution ON accreditation_items(institution_id);
CREATE INDEX IF NOT EXISTS idx_audit_institution_created ON security_audit_log(institution_id, created_at);
