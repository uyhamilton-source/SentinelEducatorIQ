# Database migrations

The application initializes its current schema idempotently at startup for SQLite and PostgreSQL. Before a production pilot, freeze the schema and manage subsequent changes as numbered SQL migrations in `migrations/versions/`.

Apply migrations only after a verified database backup. Each migration should include an upgrade script, rollback instructions, and a tenant-isolation regression test.
