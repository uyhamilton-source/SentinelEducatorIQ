"""Database compatibility layer for SQLite development and PostgreSQL production."""
from __future__ import annotations

import os
import re
import sqlite3
from dataclasses import dataclass
from typing import Any, Iterable

POSTGRES_ID_TABLES = {
    "institutions", "reporting_periods", "students", "student_period_records",
    "executive_kpi_snapshots", "organization_units", "users", "security_audit_log",
    "data_sources", "import_batches", "import_issues", "executive_reports",
    "executive_advisor_queries", "predictive_forecast_runs", "accreditation_items",
    "institution_branding",
}


def database_url(sqlite_path: str) -> str:
    return os.environ.get("DATABASE_URL", f"sqlite:///{sqlite_path}")


def is_postgres(url: str) -> bool:
    return url.startswith("postgresql://") or url.startswith("postgres://")


def _translate_postgres_sql(sql: str) -> str:
    translated = sql.strip()
    if not translated:
        return translated
    had_ignore = bool(re.search(r"\bINSERT\s+OR\s+IGNORE\b", translated, flags=re.I))
    translated = re.sub(r"\bINSERT\s+OR\s+IGNORE\s+INTO\b", "INSERT INTO", translated, flags=re.I)
    if had_ignore and "ON CONFLICT" not in translated.upper():
        translated = translated.rstrip(";") + " ON CONFLICT DO NOTHING"
    translated = translated.replace("?", "%s")
    return translated


def postgres_schema(schema: str) -> str:
    schema = re.sub(r"^\s*PRAGMA[^;]+;", "", schema, flags=re.I | re.M)
    schema = schema.replace("INTEGER PRIMARY KEY AUTOINCREMENT", "SERIAL PRIMARY KEY")
    return schema


@dataclass
class CursorAdapter:
    cursor: Any
    lastrowid: int | None = None

    def fetchone(self):
        return self.cursor.fetchone()

    def fetchall(self):
        return self.cursor.fetchall()


class PostgresConnectionAdapter:
    def __init__(self, url: str):
        try:
            import psycopg
            from psycopg.rows import dict_row
        except ImportError as exc:
            raise RuntimeError("PostgreSQL mode requires psycopg[binary].") from exc
        normalized = "postgresql://" + url[len("postgres://"):] if url.startswith("postgres://") else url
        self._conn = psycopg.connect(normalized, row_factory=dict_row)

    def execute(self, sql: str, params: Iterable[Any] = ()) -> CursorAdapter:
        original = sql
        statement = _translate_postgres_sql(sql)
        if not statement:
            return CursorAdapter(self._conn.cursor())
        cursor = self._conn.cursor()
        table_match = re.match(r"\s*INSERT\s+(?:OR\s+IGNORE\s+)?INTO\s+([A-Za-z_][A-Za-z0-9_]*)", original, re.I)
        expects_id = bool(table_match and table_match.group(1).lower() in POSTGRES_ID_TABLES)
        if expects_id and "RETURNING" not in statement.upper():
            statement = statement.rstrip(";") + " RETURNING id"
        cursor.execute(statement, tuple(params or ()))
        lastrowid = None
        if expects_id:
            row = cursor.fetchone()
            if row:
                lastrowid = row.get("id") if isinstance(row, dict) else row[0]
        return CursorAdapter(cursor, lastrowid)

    def executemany(self, sql: str, seq_of_params):
        statement = _translate_postgres_sql(sql)
        cursor = self._conn.cursor()
        cursor.executemany(statement, seq_of_params)
        return CursorAdapter(cursor)

    def executescript(self, script: str):
        translated = postgres_schema(script)
        cursor = self._conn.cursor()
        for statement in translated.split(";"):
            if statement.strip():
                cursor.execute(statement)
        return CursorAdapter(cursor)

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()


class SQLiteConnectionAdapter:
    def __init__(self, path: str):
        os.makedirs(os.path.dirname(path), exist_ok=True)
        self._conn = sqlite3.connect(path)
        self._conn.row_factory = sqlite3.Row
        self._conn.execute("PRAGMA foreign_keys = ON")

    def execute(self, sql: str, params: Iterable[Any] = ()):
        return self._conn.execute(sql, tuple(params or ()))

    def executemany(self, sql: str, seq_of_params):
        return self._conn.executemany(sql, seq_of_params)

    def executescript(self, script: str):
        return self._conn.executescript(script)

    def commit(self):
        self._conn.commit()

    def rollback(self):
        self._conn.rollback()

    def close(self):
        self._conn.close()


def connect(sqlite_path: str):
    url = database_url(sqlite_path)
    if is_postgres(url):
        return PostgresConnectionAdapter(url)
    return SQLiteConnectionAdapter(sqlite_path)
