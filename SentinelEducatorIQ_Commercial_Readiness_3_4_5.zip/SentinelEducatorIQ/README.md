# SentinelEducatorIQ™

**Executive Academic Intelligence Platform**

SentinelEducatorIQ turns academic, student-success, accreditation, and operational data into role-aware executive intelligence for higher-education leaders.

## Included capabilities

- Executive dashboard and Institution Health Index
- Reporting-period trends and program drill-downs
- Student-risk and degree-progress intelligence
- Accreditation and compliance readiness
- Data import, lineage, and quality controls
- Role-based access and organizational scope
- Executive PDF and Excel reporting
- Predictive intelligence and evidence-backed executive advisor
- Institutional white-label branding and presentation mode

## Quick demonstration

Requirements: Python 3.11 or newer.

```bash
python -m venv .venv
```

Windows PowerShell:

```powershell
.venv\Scripts\Activate.ps1
pip install -r requirements.txt
python app.py
```

macOS or Linux:

```bash
source .venv/bin/activate
pip install -r requirements.txt
python app.py
```

Open `http://127.0.0.1:5000`.

The included database is populated with synthetic demonstration data. Sign in with:

- Email: `admin@demo.edu`
- Password: `Demo-Executive-2026!`

See `docs/DEMO_GUIDE.md` for role accounts and a demonstration script.

## Rebuild demonstration data

```bash
python scripts/seed_demo.py --reset
```

The generator creates 1,200 fictional students, 18 programs, four reporting periods, role-specific users, organizational hierarchy, KPI history, and accreditation records.

## Production configuration

Copy `.env.example` values into your deployment environment. Never use the demonstration credentials or default secret in production.

The current build uses SQLite and is intended for demonstrations and controlled design-partner pilots. A hosted multi-institution release should use PostgreSQL, migrations, tenant-bound authentication, institutional SSO, encrypted object storage, monitoring, backups, and an independent security assessment.

## Project structure

```text
app.py                       Flask application and routes
database.py                  Schema and data-access functions
program_requirements.py      Academic program requirement definitions
services/                    Analytics, reporting, advisor, and forecasting services
templates/                   Application views
scripts/seed_demo.py         Repeatable synthetic demo-data generator
sample_data/                 Safe import examples
docs/DEMO_GUIDE.md           Demonstration accounts and walkthrough
instance/                    Local SQLite database (demo/pilot only)
uploads/                     Runtime uploads; not distributed with customer data
```

## Data notice

All records in the distributed demonstration environment are fictional. Do not use real student data until the institution has completed privacy, security, FERPA, contractual, and deployment reviews.

## Automated tests

Install development dependencies and run:

```bash
pytest
pytest --cov=. --cov-report=term-missing
```

The test suite covers health checks, authentication, protected routes, security headers, and tenant-bound sessions. Add regression tests for every new route and database change.

## Database modes

Local development uses SQLite by default:

```bash
python app.py
```

Production can use PostgreSQL by setting `DATABASE_URL`:

```text
postgresql://sentinel:password@localhost:5432/sentineleduiq
```

Tenant resolution is bound to the authenticated user's `institution_id`. The institution code on the login screen is used only to locate the correct tenant during authentication; authenticated routes do not trust URL or form tenant identifiers.

## Docker production deployment

1. Copy `.env.production.example` to `.env`.
2. Replace every placeholder with secure values.
3. Run:

```bash
docker compose up -d --build
```

4. Confirm readiness:

```bash
curl http://127.0.0.1/healthz
```

The production stack includes PostgreSQL 16, Gunicorn, Nginx, persistent database storage, persistent upload storage, and container health checks. Configure a real domain and TLS certificate before enabling secure cookies for external access.
